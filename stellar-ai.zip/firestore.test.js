const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_stellar_1";
const BOB_UID = "bob_stellar_2";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write any user profile, conversation, or message", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const now = new Date(Date.now() - 1000);

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("conversations")
      .get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Hacker",
      avatarPreset: "stellar_default",
      preferredLanguage: "th",
      analyticsConsent: false,
      memoryConsent: true,
      subscriptionTier: "free",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("UserProfile: owner can create free profile, update allowed fields, and cannot escalate subscriptionTier or spoof createdAt", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 5000);

  // Valid create (no optional null fields, subscriptionTier == free)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Niran",
      email: "niran@example.com",
      avatarPreset: "stellar_default",
      preferredLanguage: "th",
      analyticsConsent: true,
      memoryConsent: true,
      subscriptionTier: "free",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Valid partial update
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      preferredLanguage: "en",
      analyticsConsent: false,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject self-escalation of subscriptionTier
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      subscriptionTier: "pro_yearly",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject immutable createdAt mutation
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 200),
      updatedAt: new Date(Date.now() - 200),
    })
  );

  // Reject shadow field injection
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 200),
    })
  );

  // Reject future timestamp
  await assertFails(
    aliceDb.collection("users").doc("spoof_future").set({
      userId: "spoof_future",
      displayName: "Spoof",
      avatarPreset: "stellar_default",
      preferredLanguage: "th",
      analyticsConsent: false,
      memoryConsent: true,
      subscriptionTier: "free",
      createdAt: new Date(Date.now() + 60000),
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Conversations & Messages: Kotlin payloads, batch creation, list queries, and cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 10000);

  const convRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("conversations")
    .doc("conv_1");

  const msgRef = convRef.collection("messages").doc("msg_1");

  // Batch create conversation + initial message (uses existsAfter in rules)
  const batch = aliceDb.batch();
  batch.set(convRef, {
    userId: ALICE_UID,
    title: "วางแผนทริปเชียงใหม่",
    lastMessagePreview: "ช่วยวางแผนเที่ยวเชียงใหม่ 3 วัน 2 คืนหน่อย",
    mode: "chat",
    messageCount: 1,
    pinned: false,
    createdAt: created,
    updatedAt: created,
  });
  batch.set(msgRef, {
    userId: ALICE_UID,
    conversationId: "conv_1",
    role: "user",
    content: "ช่วยวางแผนเที่ยวเชียงใหม่ 3 วัน 2 คืนหน่อย",
    hasImage: false,
    createdAt: created,
  });
  await assertSucceeds(batch.commit());

  // List conversations & messages as owner
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("conversations")
      .get()
  );
  await assertSucceeds(convRef.collection("messages").get());

  // Pin toggle update
  await assertSucceeds(
    convRef.update({
      pinned: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject @DocumentId "id" ghost field in payload
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("conversations")
      .doc("conv_bad")
      .set({
        id: "conv_bad",
        userId: ALICE_UID,
        title: "Invalid ID field",
        lastMessagePreview: "Test",
        mode: "chat",
        messageCount: 0,
        pinned: false,
        createdAt: created,
        updatedAt: created,
      })
  );

  // Cross-user isolation: Bob cannot read or write Alice's conversations or profile
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("conversations")
      .get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("conversations")
      .doc("conv_1")
      .update({ pinned: false, updatedAt: new Date(Date.now() - 500) })
  );
});

test("Account deletion requests: owner can create pending request, cannot tamper status", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 1000);

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("account_requests")
      .doc("req_1")
      .set({
        userId: ALICE_UID,
        reason: "Testing account deletion flow",
        status: "pending",
        createdAt: created,
      })
  );

  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("account_requests")
      .doc("req_2")
      .set({
        userId: ALICE_UID,
        reason: "Bad status",
        status: "approved",
        createdAt: created,
      })
  );
});
