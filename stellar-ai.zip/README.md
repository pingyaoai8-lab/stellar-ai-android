# STELLAR AI — Native Android Client

> **Your Intelligent Universe** — Native Kotlin & Jetpack Compose AI assistant built with Material Design 3, Firebase Authentication, Cloud Firestore, Firebase App Check, Firebase AI Logic, and a backend-ready API gateway.

---

## Pre-Release Status Notice

This repository provides a **complete, navigable Android MVP** with real Firebase Authentication (Google Sign-In via Jetpack Credential Manager), Cloud Firestore persistence, Firebase App Check wiring, and Firebase AI Logic (`gemini-3.8-flash`).

**Do NOT submit to Google Play Store as production-ready until you complete:**
1. Server-side Cloud Functions / Cloud Run deployment for custom proxy endpoints and Play Billing entitlement verification.
2. Google Play Billing product ID configuration (`stellar_pro_monthly`, `stellar_pro_yearly`) in Google Play Console.
3. Legal entity details, DPO contact email, and Google Play Data Safety declarations (marked `[TO BE COMPLETED BEFORE PLAY RELEASE]` in `AppStrings.kt`).
4. Server-side permanent account/data deletion handler triggered by `/users/{userId}/account_requests/{requestId}`.

---

## Architecture Overview

- **UI Layer**: 100% Jetpack Compose + Material 3 (`StellarAITheme`), cosmic dark navy (`#050814` / `#090F24`) with electric blue (`#38BDF8`) and violet (`#8B5CF6`) glassmorphism cards, bundled Google Fonts (`Space Grotesk`, `Plus Jakarta Sans`, `Noto Sans Thai`), adaptive `NavigationBar` / `NavigationRail`, and edge-to-edge insets.
- **Localization**: **Thai (`th`) is the default language** with instant in-app switching to **English (`en`)** via `AppStrings` + DataStore (`UserPreferencesRepository`) + Android `strings.xml` / `values-en/strings.xml`.
- **ViewModel & State**: MVVM with `StateFlow`, `collectAsStateWithLifecycle()`, sealed `UiState<T>`, and cooperative `CancellationException` handling.
- **Data & Repositories**:
  - `FirestoreRepository`: Scoped per-user paths under `/users/{userId}` using the provisioned named database (`R.string.firestore_database_id`), `FieldValue.serverTimestamp()`, `ServerTimestampBehavior.ESTIMATE`, and `handleFirestoreError(...)`.
  - `AiRepository` (`FirebaseAiRepository`): Uses `Firebase.ai.generativeModel("gemini-3.8-flash")` with `generateContentStream()`, structured JSON (`Schema.obj`), and multimodal vision (`content { image(...); text(...) }`) protected by Firebase App Check.
  - `StellarBackendApi`: Retrofit + Moshi interface with `StellarAuthInterceptor` (attaching Firebase ID Token + App Check Token) ready for your Cloud Functions / Cloud Run proxy.
  - `SubscriptionRepository` (`PlayBillingSubscriptionRepository`): Honest, non-faking subscription layer that remains `NotConfigured` until Play Console product IDs and backend verification are connected.

---

## Included Screens

1. **Splash Screen** — Animated cosmic star emblem and Stellar avatar
2. **Onboarding** — 3-slide `HorizontalPager` with live Thai/English toggle
3. **Sign In & Sign Up (`AuthScreen`)** — Google Sign-In via Jetpack Credential Manager (`GetSignInWithGoogleOption`)
4. **Home Dashboard** — Personalized greeting, assistant hero card, 2x2 quick tools, prompt starters, recent conversations, Pro banner
5. **AI Chat** — Live streaming presentation, user & assistant bubbles, copy, regenerate, stop generation, new chat, error/retry states
6. **Conversation History** — Searchable Firestore threads, pin/unpin, delete confirmation
7. **AI Search** — Structured JSON synthesis (Summary, Key Takeaways, Follow-Up Questions)
8. **Image Analysis** — Zero-permission Android Photo Picker (`PickVisualMedia`) + multimodal Gemini vision
9. **Voice Assistant UI** — Animated waveform orb, `RECORD_AUDIO` runtime permission flow, `SpeechRecognizer` + `TextToSpeech` + text fallback
10. **Profile** — Replaceable assistant avatar via Photo Picker, editable display name, membership tier, account deletion entry point
11. **Settings** — Thai/English switcher, privacy consent toggles, voice auto-speak, security diagnostics, sign out
12. **Subscription Plans** — Monthly & Yearly plans (Play Billing configuration status banner, no fake purchases)
13. **Privacy Policy** — Pre-release Data Safety & privacy notice template + account deletion entry
14. **Help** — Expandable FAQ accordion & developer setup reference

---

## Setup Instructions

### 1. Firebase Configuration
- Ensure `app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml` are present for your Firebase project (provisioned in AI Studio or downloaded from Firebase Console).
- Register your debug and release keystore SHA-1 & SHA-256 fingerprints in Firebase Console so Google Sign-In (`CredentialManager`) succeeds.
- Enable **Google** as a sign-in provider in **Firebase Authentication**.
- Deploy `firestore.rules` to your named Firestore database (`R.string.firestore_database_id`) and test locally:
  ```bash
  FIRESTORE_EMULATOR_HOST="127.0.0.1:8085" node --test firestore.test.js
  ```

### 2. Firebase App Check & Gemini Configuration
- `MainActivity.onCreate()` calls `configureAppCheck(this, intent)` before `setContent`.
- Debug builds use `DebugAppCheckProviderFactory` (with `FIREBASE_APPCHECK_DEBUG_TOKEN` intent extra); release builds use `RecaptchaAppCheckProviderFactory` reading `R.string.recaptcha_site_key`.
- **Security rule**: Never place Gemini API keys, service account JSONs, or billing secrets in Android source code, `.env`, or `BuildConfig`.

### 3. Server-Side Backend Deployment (Cloud Functions / Cloud Run)
When routing AI or Play Billing verification through your own server:
1. Deploy a Cloud Run or Firebase Cloud Functions v2 service implementing the endpoints in `StellarBackendApi.kt`:
   - `POST /v1/chat/completions`
   - `POST /v1/search/grounded`
   - `POST /v1/subscriptions/verify`
   - `DELETE /v1/account`
2. Verify both `Authorization: Bearer <Firebase ID Token>` (via Firebase Admin SDK `auth().verifyIdToken(...)`) and `X-Firebase-AppCheck` (via `appCheck().verifyToken(...)`) on every request.
3. Store `GEMINI_API_KEY` and Google Play Developer API service credentials solely in **Cloud Secret Manager** on the backend.
4. Configure your HTTPS base URL via `StellarBackendFactory.create(baseUrl)`.

### 4. Google Play Billing Setup
1. Create subscription products `stellar_pro_monthly` and `stellar_pro_yearly` in **Google Play Console → Monetize → Subscriptions**.
2. Add the official Google Play Billing Library (`com.android.billingclient:billing-ktx`) to `app/build.gradle.kts`.
3. Implement `PlayBillingSubscriptionRepository` to launch `BillingClient.launchBillingFlow(...)`, send the resulting `purchaseToken` to `POST /v1/subscriptions/verify`, and acknowledge purchases server-side before updating `users/{userId}.subscriptionTier`.

### 5. Build & Test Commands
```bash
# Compile Kotlin & verify resources
gradle :app:compileDebugKotlin

# Build debug APK
gradle :app:assembleDebug

# Run local JVM unit tests
gradle :app:testDebugUnitTest
```
