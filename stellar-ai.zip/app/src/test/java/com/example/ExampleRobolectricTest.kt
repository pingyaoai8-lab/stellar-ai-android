package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.stringsFor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Stellar AI", appName)
    }

    @Test
    fun `default language is Thai and English localization is supported`() {
        assertEquals(AppLanguage.THAI, AppLanguage.fromCode(null))
        val th = stringsFor(AppLanguage.THAI)
        val en = stringsFor(AppLanguage.ENGLISH)
        assertTrue(th.tagline.isNotBlank())
        assertEquals("Your Intelligent Universe", en.tagline)
    }
}
