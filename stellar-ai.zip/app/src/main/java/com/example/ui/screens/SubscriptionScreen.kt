package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.i18n.LocalAppStrings
import com.example.domain.model.BillingConfigState
import com.example.domain.model.PlanBillingCycle
import com.example.domain.model.SubscriptionPlan
import com.example.ui.components.GlassCard
import com.example.ui.components.StellarGradientButton
import com.example.ui.components.StellarTopBar
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CosmicViolet
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarGlassBorderStart
import com.example.ui.theme.StellarGlassFill

@Composable
fun SubscriptionScreen(
    plans: List<SubscriptionPlan>,
    billingConfigState: BillingConfigState,
    feedbackMessage: String?,
    onBack: () -> Unit,
    onSelectPlan: (Activity?, SubscriptionPlan) -> Unit,
    onRestorePurchases: () -> Unit,
    onClearFeedback: () -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val activity = context as? Activity
    val snackbarHostState = remember { SnackbarHostState() }
    var selectedCycle by remember { mutableStateOf(PlanBillingCycle.YEARLY) }

    LaunchedEffect(feedbackMessage) {
        if (!feedbackMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(feedbackMessage)
            onClearFeedback()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp)
                .align(Alignment.TopCenter)
        ) {
            StellarTopBar(
                title = strings.subsTitle,
                subtitle = strings.subsSubtitle,
                onBack = onBack
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (billingConfigState is BillingConfigState.NotConfigured) {
                    Surface(
                        color = AmberWarning.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Info,
                                contentDescription = null,
                                tint = AmberWarning,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = strings.subsStatusBannerTitle,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = AmberWarning
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = strings.subsStatusBannerBody,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NebulaSilver
                                )
                            }
                        }
                    }
                }

                // Plan Cards
                plans.forEach { plan ->
                    val isSelected = plan.cycle == selectedCycle
                    val borderBrush = if (isSelected) {
                        Brush.linearGradient(listOf(ElectricBlue, CosmicViolet))
                    } else {
                        Brush.linearGradient(listOf(StellarGlassBorderStart.copy(alpha = 0.35f), StellarGlassBorderStart.copy(alpha = 0.35f)))
                    }
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = StellarGlassFill,
                        border = BorderStroke(if (isSelected) 2.dp else 1.dp, borderBrush),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { selectedCycle = plan.cycle }
                            .testTag("subs_plan_${plan.cycle.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = plan.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = StarlightWhite
                                    )
                                    if (!plan.badge.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(50))
                                                .background(
                                                    Brush.horizontalGradient(listOf(ElectricBlue, CosmicViolet))
                                                )
                                                .padding(horizontal = 10.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = plan.badge,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = StarlightWhite
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Product ID: ${plan.productId}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NebulaSilver
                                )
                            }
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = plan.priceDisplay,
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ElectricBlue
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = plan.periodDisplay,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NebulaSilver,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Feature Matrix
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        strings.subsFeatures.forEach { feature ->
                            Row(verticalAlignment = Alignment.Top) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = EmeraldSuccess,
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = feature,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = StarlightWhite
                                )
                            }
                        }
                    }
                }

                val selectedPlan = plans.firstOrNull { it.cycle == selectedCycle } ?: plans.first()
                StellarGradientButton(
                    text = strings.subsSubscribeCta,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.WorkspacePremium,
                            contentDescription = null,
                            tint = StarlightWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    onClick = { onSelectPlan(activity, selectedPlan) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("subs_subscribe_button")
                )

                OutlinedButton(
                    onClick = onRestorePurchases,
                    border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.6f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("subs_restore_button")
                ) {
                    Text(strings.subsRestoreCta)
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}
