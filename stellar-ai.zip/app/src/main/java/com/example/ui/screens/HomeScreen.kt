package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.domain.model.Conversation
import com.example.domain.model.UiState
import com.example.ui.components.GlassCard
import com.example.ui.components.StellarAvatar
import com.example.ui.components.StellarGradientButton
import com.example.ui.theme.CosmicViolet
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedStarlight
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarAITheme
import com.example.ui.theme.StellarDeepNavy
import com.example.ui.theme.StellarNavyElevated

@Composable
fun HomeScreen(
    displayName: String,
    customAvatarUri: String?,
    conversationsState: UiState<List<Conversation>>,
    onOpenNewChat: () -> Unit,
    onOpenChatWithPrompt: (String) -> Unit,
    onOpenConversation: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenVision: () -> Unit,
    onOpenVoice: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenSubscriptions: () -> Unit
) {
    val strings = LocalAppStrings.current

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .widthIn(max = 780.dp)
                .align(Alignment.TopCenter),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StellarAvatar(
                        customAvatarUri = customAvatarUri,
                        size = 50.dp,
                        showPulseRing = true,
                        modifier = Modifier
                            .clickable(onClick = onOpenProfile)
                            .testTag("home_avatar_button")
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${strings.homeGreetingPrefix}, $displayName",
                            style = MaterialTheme.typography.titleLarge,
                            color = StarlightWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = strings.tagline,
                            style = MaterialTheme.typography.bodySmall,
                            color = ElectricBlue
                        )
                    }
                    IconButton(
                        onClick = onOpenProfile,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_profile_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Person,
                            contentDescription = strings.navProfile,
                            tint = NebulaSilver
                        )
                    }
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("home_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = strings.navSettings,
                            tint = NebulaSilver
                        )
                    }
                }
            }

            // Hero Cosmic Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_stellar_nebula_hero),
                            contentDescription = stringResource(R.string.cd_cosmic_backdrop),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .matchParentSize()
                                .alpha(0.32f)
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            Surface(
                                color = ElectricBlue.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        tint = ElectricBlue,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = strings.assistantName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ElectricBlue
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = strings.homeHeroCardTitle,
                                style = MaterialTheme.typography.headlineMedium,
                                color = StarlightWhite
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = strings.homeHeroCardSubtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = NebulaSilver
                            )
                            Spacer(modifier = Modifier.height(18.dp))
                            StellarGradientButton(
                                text = strings.homeStartChatCta,
                                onClick = onOpenNewChat,
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.Chat,
                                        contentDescription = null,
                                        tint = StarlightWhite,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("home_start_chat_button")
                            )
                        }
                    }
                }
            }

            // Quick Tools 2x2 Grid
            item {
                Text(
                    text = strings.homeQuickToolsTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = StarlightWhite
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuickToolCard(
                        title = strings.navChat,
                        subtitle = strings.homeToolChatDesc,
                        icon = Icons.AutoMirrored.Rounded.Chat,
                        onClick = onOpenNewChat,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_tool_chat")
                    )
                    QuickToolCard(
                        title = strings.navSearch,
                        subtitle = strings.homeToolSearchDesc,
                        icon = Icons.Rounded.Search,
                        onClick = onOpenSearch,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_tool_search")
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    QuickToolCard(
                        title = strings.navVision,
                        subtitle = strings.homeToolVisionDesc,
                        icon = Icons.Rounded.ImageSearch,
                        onClick = onOpenVision,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_tool_vision")
                    )
                    QuickToolCard(
                        title = strings.navVoice,
                        subtitle = strings.homeToolVoiceDesc,
                        icon = Icons.Rounded.GraphicEq,
                        onClick = onOpenVoice,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("home_tool_voice")
                    )
                }
            }

            // Prompt Starters
            item {
                Text(
                    text = strings.homeStartersTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = StarlightWhite
                )
            }
            items(strings.homePromptStarters) { starter ->
                GlassCard(
                    onClick = { onOpenChatWithPrompt(starter.prompt) },
                    contentPadding = PaddingValues(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = starter.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = StarlightWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = starter.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = NebulaSilver
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            tint = ElectricBlue
                        )
                    }
                }
            }

            // Recent Conversations Preview
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.homeRecentTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = StarlightWhite
                    )
                    TextButton(
                        onClick = onOpenHistory,
                        modifier = Modifier.testTag("home_view_history_button")
                    ) {
                        Text(strings.homeViewAllHistory, color = ElectricBlue)
                    }
                }
            }

            when (conversationsState) {
                is UiState.Loading -> {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = ElectricBlue, modifier = Modifier.size(28.dp))
                        }
                    }
                }

                is UiState.Error -> {
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = conversationsState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = NebulaSilver
                            )
                        }
                    }
                }

                is UiState.Success -> {
                    val recent = conversationsState.data.take(3)
                    if (recent.isEmpty()) {
                        item {
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = strings.homeNoRecentChats,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = NebulaSilver
                                )
                            }
                        }
                    } else {
                        items(recent, key = { it.id }) { conv ->
                            GlassCard(
                                onClick = { onOpenConversation(conv.id) },
                                contentPadding = PaddingValues(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column {
                                    Text(
                                        text = conv.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = StarlightWhite,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = conv.lastMessagePreview,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MutedStarlight,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Stellar Pro Banner
            item {
                GlassCard(
                    onClick = onOpenSubscriptions,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_pro_banner")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(ElectricBlue, CosmicViolet))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WorkspacePremium,
                                contentDescription = null,
                                tint = StarlightWhite
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.homeBannerProTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = StarlightWhite
                            )
                            Text(
                                text = strings.homeBannerProSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = NebulaSilver
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            tint = ElectricBlue
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun QuickToolCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        onClick = onClick,
        contentPadding = PaddingValues(16.dp),
        modifier = modifier
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(StellarNavyElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = ElectricBlue,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = StarlightWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MutedStarlight,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun HomeScreenPreview() {
    StellarAITheme(language = AppLanguage.THAI) {
        Box(modifier = Modifier.background(StellarDeepNavy)) {
            HomeScreen(
                displayName = "ชนาธิป",
                customAvatarUri = null,
                conversationsState = UiState.Success(emptyList()),
                onOpenNewChat = {},
                onOpenChatWithPrompt = {},
                onOpenConversation = {},
                onOpenSearch = {},
                onOpenVision = {},
                onOpenVoice = {},
                onOpenHistory = {},
                onOpenProfile = {},
                onOpenSettings = {},
                onOpenSubscriptions = {}
            )
        }
    }
}
