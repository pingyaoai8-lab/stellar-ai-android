package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.ui.components.GlassCard
import com.example.ui.components.StellarAvatar
import com.example.ui.components.StellarGradientButton
import com.example.ui.components.StellarTopBar
import com.example.ui.theme.CoralError
import com.example.ui.theme.CosmicViolet
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedStarlight
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarGlassBorderStart
import com.example.ui.theme.StellarNavySurface
import com.example.ui.viewmodel.VoicePhase
import com.example.ui.viewmodel.VoiceUiState
import java.util.Locale

@Composable
fun VoiceAssistantScreen(
    uiState: VoiceUiState,
    customAvatarUri: String?,
    currentLanguage: AppLanguage,
    autoSpeakEnabled: Boolean,
    onBack: () -> Unit,
    onToggleAutoSpeak: (Boolean) -> Unit,
    onFallbackInputChanged: (String) -> Unit,
    onSubmitTranscript: (String, (String) -> Unit) -> Unit,
    onListeningChanged: (Boolean) -> Unit,
    onSpeakingChanged: (Boolean) -> Unit,
    onVoiceError: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val ttsRef = remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context, currentLanguage) {
        val tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val locale = if (currentLanguage == AppLanguage.THAI) Locale("th", "TH") else Locale.US
                ttsRef.value?.language = locale
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                onSpeakingChanged(false)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                onSpeakingChanged(false)
            }
        })
        ttsRef.value = tts
        onDispose {
            tts.stop()
            tts.shutdown()
            ttsRef.value = null
        }
    }

    val speakReply: (String) -> Unit = { text ->
        if (autoSpeakEnabled && ttsRef.value != null) {
            val locale = if (currentLanguage == AppLanguage.THAI) Locale("th", "TH") else Locale.US
            ttsRef.value?.language = locale
            ttsRef.value?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "stellar_voice_reply")
        } else {
            onSpeakingChanged(false)
        }
    }

    val recognizer = remember(context) {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else {
            null
        }
    }

    DisposableEffect(recognizer) {
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = onListeningChanged(true)
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() = onListeningChanged(false)
            override fun onError(error: Int) {
                onListeningChanged(false)
                onVoiceError(strings.voicePermissionRequired)
            }

            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!spoken.isNullOrBlank()) {
                    onSubmitTranscript(spoken, speakReply)
                } else {
                    onListeningChanged(false)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        onDispose {
            recognizer?.destroy()
        }
    }

    val startListening = {
        if (recognizer == null) {
            onVoiceError(strings.voicePermissionRequired)
        } else {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE,
                    if (currentLanguage == AppLanguage.THAI) "th-TH" else "en-US"
                )
            }
            onListeningChanged(true)
            recognizer.startListening(intent)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasAudioPermission = granted
        if (granted) {
            startListening()
        } else {
            onVoiceError(strings.voicePermissionRequired)
        }
    }

    val transition = rememberInfiniteTransition(label = "voice_orb")
    val waveScale by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (uiState.phase == VoicePhase.IDLE) 2400 else 900,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave_scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .widthIn(max = 720.dp)
    ) {
        StellarTopBar(
            title = strings.voiceTitle,
            subtitle = strings.voiceSubtitle,
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Animated Cosmic Orb
            Box(
                modifier = Modifier.size(210.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val baseR = size.minDimension * 0.34f
                    val activeAlpha = if (uiState.phase == VoicePhase.IDLE) 0.25f else 0.55f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(ElectricBlue.copy(alpha = activeAlpha), Color.Transparent)
                        ),
                        radius = baseR * waveScale * 1.35f
                    )
                    drawCircle(
                        color = ElectricBlue.copy(alpha = 0.45f),
                        radius = baseR * waveScale,
                        style = Stroke(width = 3f)
                    )
                    drawCircle(
                        color = CosmicViolet.copy(alpha = 0.4f),
                        radius = baseR * (2f - waveScale * 0.8f),
                        style = Stroke(width = 2f)
                    )
                }
                StellarAvatar(
                    customAvatarUri = customAvatarUri,
                    size = 112.dp,
                    showPulseRing = uiState.phase != VoicePhase.IDLE
                )
            }

            val phaseLabel = when (uiState.phase) {
                VoicePhase.IDLE -> strings.voiceIdleStatus
                VoicePhase.LISTENING -> strings.voiceListeningStatus
                VoicePhase.THINKING -> strings.voiceThinkingStatus
                VoicePhase.SPEAKING -> strings.voiceSpeakingStatus
            }

            Text(
                text = phaseLabel,
                style = MaterialTheme.typography.titleMedium,
                color = ElectricBlue,
                textAlign = TextAlign.Center
            )

            StellarGradientButton(
                text = if (uiState.phase == VoicePhase.LISTENING) strings.voiceTapToStop else strings.voiceTapToSpeak,
                isLoading = uiState.phase == VoicePhase.THINKING,
                leadingIcon = {
                    Icon(
                        imageVector = if (uiState.phase == VoicePhase.LISTENING) Icons.Rounded.Stop else Icons.Rounded.Mic,
                        contentDescription = null,
                        tint = StarlightWhite,
                        modifier = Modifier.size(20.dp)
                    )
                },
                onClick = {
                    if (uiState.phase == VoicePhase.LISTENING) {
                        recognizer?.stopListening()
                        onListeningChanged(false)
                    } else if (hasAudioPermission) {
                        startListening()
                    } else {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("voice_mic_button")
            )

            if (uiState.transcript.isNotBlank() || uiState.reply.isNotBlank()) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (uiState.transcript.isNotBlank()) {
                            Text(
                                text = "You: ${uiState.transcript}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NebulaSilver
                            )
                        }
                        if (uiState.reply.isNotBlank()) {
                            Text(
                                text = uiState.reply,
                                style = MaterialTheme.typography.bodyLarge,
                                color = StarlightWhite
                            )
                        }
                    }
                }
            }

            if (!uiState.errorMessage.isNullOrBlank()) {
                Text(
                    text = uiState.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = CoralError,
                    textAlign = TextAlign.Center
                )
            }

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = strings.voiceAutoSpeakLabel,
                        style = MaterialTheme.typography.bodyMedium,
                        color = StarlightWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = autoSpeakEnabled,
                        onCheckedChange = onToggleAutoSpeak,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = StarlightWhite,
                            checkedTrackColor = ElectricBlue
                        )
                    )
                }
            }

            // Text fallback composer
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = strings.voiceFallbackLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = NebulaSilver
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = uiState.fallbackInput,
                        onValueChange = onFallbackInputChanged,
                        placeholder = {
                            Text(strings.voiceFallbackPlaceholder, color = MutedStarlight)
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = StellarGlassBorderStart.copy(alpha = 0.4f),
                            focusedContainerColor = StellarNavySurface,
                            unfocusedContainerColor = StellarNavySurface,
                            focusedTextColor = StarlightWhite,
                            unfocusedTextColor = StarlightWhite
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("voice_fallback_input")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        enabled = uiState.fallbackInput.isNotBlank() && uiState.phase != VoicePhase.THINKING,
                        onClick = { onSubmitTranscript(uiState.fallbackInput, speakReply) },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("voice_fallback_send")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.Send,
                            contentDescription = strings.chatSendCd,
                            tint = ElectricBlue
                        )
                    }
                }
            }
        }
    }
}
