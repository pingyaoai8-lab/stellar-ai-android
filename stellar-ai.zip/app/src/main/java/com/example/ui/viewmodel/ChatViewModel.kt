package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.i18n.AppLanguage
import com.example.data.repository.AiRepository
import com.example.data.repository.FirestoreRepository
import com.example.domain.model.AssistantMode
import com.example.domain.model.ChatMessage
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val activeConversationId: String? = null,
    val inputText: String = "",
    val isGenerating: Boolean = false,
    val streamingReply: String = "",
    val errorMessage: String? = null,
    val lastFailedPrompt: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(
    private val firestoreRepo: FirestoreRepository,
    private val aiRepo: AiRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val _activeConversationId = MutableStateFlow<String?>(null)
    private var generationJob: Job? = null
    private var lastSubmitTimestampMs: Long = 0L

    val messages: StateFlow<List<ChatMessage>> = _activeConversationId
        .flatMapLatest { convId ->
            if (convId.isNullOrBlank()) {
                flowOf(emptyList())
            } else {
                firestoreRepo.observeMessages(currentUserId, convId)
                    .catch { error ->
                        val firestoreError = generateSequence(error) { it.cause }
                            .filterIsInstance<FirebaseFirestoreException>()
                            .firstOrNull()
                        if (firestoreError == null && error is CancellationException) throw error
                        val rootError = firestoreError ?: error
                        Log.w(TAG, "Error observing chat messages", rootError)
                        _uiState.update { it.copy(errorMessage = rootError.message ?: "Failed to load messages") }
                        emit(emptyList())
                    }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    fun selectConversation(conversationId: String?) {
        if (_activeConversationId.value != conversationId) {
            stopGeneration()
            _activeConversationId.value = conversationId
            _uiState.update {
                it.copy(
                    activeConversationId = conversationId,
                    errorMessage = null,
                    streamingReply = "",
                    isGenerating = false
                )
            }
        }
    }

    fun startNewChat() {
        stopGeneration()
        _activeConversationId.value = null
        _uiState.update {
            ChatUiState(activeConversationId = null)
        }
    }

    fun onInputChanged(text: String) {
        _uiState.update { it.copy(inputText = text, errorMessage = null) }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun sendMessage(language: AppLanguage, overridePrompt: String? = null) {
        val rawPrompt = (overridePrompt ?: _uiState.value.inputText).trim()
        if (rawPrompt.isEmpty()) return
        if (rawPrompt.length > MAX_PROMPT_LENGTH) {
            _uiState.update {
                it.copy(
                    errorMessage = if (language == AppLanguage.THAI) {
                        "ข้อความยาวเกิน 4,000 ตัวอักษร กรุณาย่อข้อความก่อนส่ง"
                    } else {
                        "Prompt exceeds 4,000 characters. Please shorten your message."
                    }
                )
            }
            return
        }

        val now = System.currentTimeMillis()
        if (_uiState.value.isGenerating || (now - lastSubmitTimestampMs < MIN_SUBMIT_INTERVAL_MS)) {
            return
        }
        lastSubmitTimestampMs = now

        if (overridePrompt == null) {
            _uiState.update { it.copy(inputText = "") }
        }

        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGenerating = true,
                    streamingReply = "",
                    errorMessage = null,
                    lastFailedPrompt = null
                )
            }

            val historySnapshot = messages.value
            var convId = _activeConversationId.value

            // Persist user message to Firestore first
            if (convId.isNullOrBlank()) {
                val createResult = firestoreRepo.createConversationWithInitialMessage(
                    userId = currentUserId,
                    title = rawPrompt.take(48),
                    mode = AssistantMode.CHAT,
                    initialRole = "user",
                    initialContent = rawPrompt
                )
                if (createResult.isFailure) {
                    _uiState.update {
                        it.copy(
                            isGenerating = false,
                            errorMessage = createResult.exceptionOrNull()?.localizedMessage
                                ?: "Unable to save conversation",
                            lastFailedPrompt = rawPrompt
                        )
                    }
                    return@launch
                }
                convId = createResult.getOrThrow()
                _activeConversationId.value = convId
                _uiState.update { it.copy(activeConversationId = convId) }
            } else {
                val appendResult = firestoreRepo.appendMessage(
                    userId = currentUserId,
                    conversationId = convId,
                    role = "user",
                    content = rawPrompt
                )
                if (appendResult.isFailure) {
                    _uiState.update {
                        it.copy(
                            isGenerating = false,
                            errorMessage = appendResult.exceptionOrNull()?.localizedMessage
                                ?: "Unable to send message",
                            lastFailedPrompt = rawPrompt
                        )
                    }
                    return@launch
                }
            }

            streamAssistantReply(
                conversationId = convId,
                history = historySnapshot,
                prompt = rawPrompt,
                language = language
            )
        }
    }

    fun regenerateLastResponse(language: AppLanguage) {
        if (_uiState.value.isGenerating) return
        val convId = _activeConversationId.value ?: return
        val currentMsgs = messages.value
        val lastUserMsg = currentMsgs.lastOrNull { !it.fromAssistant } ?: return
        val historyBeforeLastUser = currentMsgs.takeWhile { it.id != lastUserMsg.id }

        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGenerating = true,
                    streamingReply = "",
                    errorMessage = null,
                    lastFailedPrompt = null
                )
            }
            streamAssistantReply(
                conversationId = convId,
                history = historyBeforeLastUser,
                prompt = lastUserMsg.content,
                language = language
            )
        }
    }

    fun stopGeneration() {
        val partial = _uiState.value.streamingReply.trim()
        val convId = _activeConversationId.value
        generationJob?.cancel()
        generationJob = null
        _uiState.update {
            it.copy(
                isGenerating = false,
                streamingReply = ""
            )
        }
        if (partial.isNotEmpty() && !convId.isNullOrBlank()) {
            viewModelScope.launch {
                firestoreRepo.appendMessage(
                    userId = currentUserId,
                    conversationId = convId,
                    role = "assistant",
                    content = partial
                )
            }
        }
    }

    private suspend fun streamAssistantReply(
        conversationId: String,
        history: List<ChatMessage>,
        prompt: String,
        language: AppLanguage
    ) {
        var finalText = ""
        try {
            aiRepo.streamChatReply(
                history = history,
                userPrompt = prompt,
                language = language
            ).collect { accumulated ->
                finalText = accumulated
                _uiState.update { it.copy(streamingReply = accumulated) }
            }

            if (finalText.isNotBlank()) {
                firestoreRepo.appendMessage(
                    userId = currentUserId,
                    conversationId = conversationId,
                    role = "assistant",
                    content = finalText
                )
            }
            _uiState.update {
                it.copy(
                    isGenerating = false,
                    streamingReply = "",
                    errorMessage = null
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI streaming error", e)
            _uiState.update {
                it.copy(
                    isGenerating = false,
                    streamingReply = "",
                    errorMessage = e.localizedMessage ?: "AI request failed",
                    lastFailedPrompt = prompt
                )
            }
        }
    }

    private companion object {
        const val TAG = "ChatVM"
        const val MAX_PROMPT_LENGTH = 4000
        const val MIN_SUBMIT_INTERVAL_MS = 600L
    }
}
