package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.FirestoreRepository
import com.example.domain.model.Conversation
import com.example.domain.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryAndHomeViewModel(
    private val firestoreRepo: FirestoreRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    val conversationsState: StateFlow<UiState<List<Conversation>>> = firestoreRepo
        .observeConversations(currentUserId)
        .map<List<Conversation>, UiState<List<Conversation>>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing conversations", rootError)
            emit(UiState.Error(rootError.message ?: "Failed to load conversations"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = UiState.Loading
        )

    val filteredConversations: StateFlow<UiState<List<Conversation>>> = combine(
        conversationsState,
        _searchQuery
    ) { state, query ->
        when (state) {
            is UiState.Loading -> UiState.Loading
            is UiState.Error -> state
            is UiState.Success -> {
                val clean = query.trim()
                if (clean.isEmpty()) {
                    state
                } else {
                    UiState.Success(
                        state.data.filter {
                            it.title.contains(clean, ignoreCase = true) ||
                                it.lastMessagePreview.contains(clean, ignoreCase = true)
                        }
                    )
                }
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = UiState.Loading
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun togglePin(conversation: Conversation) {
        viewModelScope.launch {
            val result = firestoreRepo.togglePinConversation(
                userId = currentUserId,
                conversationId = conversation.id,
                pinned = !conversation.pinned
            )
            if (result.isFailure) {
                _actionMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to update pin"
            }
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            val result = firestoreRepo.deleteConversation(
                userId = currentUserId,
                conversationId = conversationId
            )
            if (result.isFailure) {
                _actionMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to delete conversation"
            }
        }
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }

    private companion object {
        const val TAG = "HistoryHomeVM"
    }
}
