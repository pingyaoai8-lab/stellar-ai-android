package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.HelpOutline
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.data.repository.LocalAppPreferences
import com.example.ui.components.GlassCard
import com.example.ui.components.StellarTopBar
import com.example.ui.theme.CoralError
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.MutedStarlight
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarDeepNavy
import com.example.ui.theme.StellarNavySurface

@Composable
fun SettingsScreen(
    preferences: LocalAppPreferences,
    showDeleteDialogInitial: Boolean = false,
    onBack: () -> Unit,
    onLanguageChanged: (AppLanguage) -> Unit,
    onAnalyticsConsentChanged: (Boolean) -> Unit,
    onMemoryConsentChanged: (Boolean) -> Unit,
    onVoiceAutoSpeakChanged: (Boolean) -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onOpenHelp: () -> Unit,
    onSignOut: () -> Unit,
    onSubmitAccountDeletion: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    var showDeleteDialog by remember(showDeleteDialogInitial) {
        mutableStateOf(showDeleteDialogInitial)
    }
    var deleteReason by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 760.dp)
    ) {
        StellarTopBar(
            title = strings.settingsTitle,
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language Card (Thai default + English)
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Translate,
                            contentDescription = null,
                            tint = ElectricBlue
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.settingsLanguageSection,
                            style = MaterialTheme.typography.titleMedium,
                            color = StarlightWhite
                        )
                    }
                    Text(
                        text = strings.settingsLanguageSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = NebulaSilver
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        AppLanguage.entries.forEachIndexed { idx, lang ->
                            SegmentedButton(
                                selected = preferences.language == lang,
                                onClick = { onLanguageChanged(lang) },
                                shape = SegmentedButtonDefaults.itemShape(
                                    index = idx,
                                    count = AppLanguage.entries.size
                                ),
                                colors = SegmentedButtonDefaults.colors(
                                    activeContainerColor = StellarNavySurface,
                                    activeContentColor = ElectricBlue,
                                    inactiveContainerColor = StellarDeepNavy,
                                    inactiveContentColor = NebulaSilver
                                ),
                                modifier = Modifier.testTag("settings_lang_${lang.code}")
                            ) {
                                Text(lang.nativeLabel)
                            }
                        }
                    }
                }
            }

            // Privacy & Consent Toggles
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.PrivacyTip,
                            contentDescription = null,
                            tint = ElectricBlue
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.settingsPrivacySection,
                            style = MaterialTheme.typography.titleMedium,
                            color = StarlightWhite
                        )
                    }

                    ConsentSwitchRow(
                        title = strings.settingsAnalyticsLabel,
                        subtitle = strings.settingsAnalyticsDesc,
                        checked = preferences.analyticsConsent,
                        onCheckedChange = onAnalyticsConsentChanged
                    )
                    ConsentSwitchRow(
                        title = strings.settingsMemoryLabel,
                        subtitle = strings.settingsMemoryDesc,
                        checked = preferences.memoryConsent,
                        onCheckedChange = onMemoryConsentChanged
                    )
                }
            }

            // Voice Settings
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = strings.settingsVoiceSection,
                        style = MaterialTheme.typography.titleMedium,
                        color = StarlightWhite
                    )
                    ConsentSwitchRow(
                        title = strings.settingsVoiceAutoSpeak,
                        subtitle = "",
                        checked = preferences.voiceAutoSpeak,
                        onCheckedChange = onVoiceAutoSpeakChanged
                    )
                }
            }

            // Security & Backend Diagnostics
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Security,
                            contentDescription = null,
                            tint = EmeraldSuccess
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.settingsSecuritySection,
                            style = MaterialTheme.typography.titleMedium,
                            color = StarlightWhite
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.VerifiedUser,
                            contentDescription = null,
                            tint = EmeraldSuccess,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = strings.settingsAppCheckStatus,
                            style = MaterialTheme.typography.bodySmall,
                            color = NebulaSilver
                        )
                    }
                    Text(
                        text = strings.settingsBackendGatewayStatus,
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedStarlight
                    )
                }
            }

            // Policy & Help links
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenPrivacyPolicy,
                    border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.5f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricBlue),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("settings_privacy_button")
                ) {
                    Icon(Icons.Rounded.PrivacyTip, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.navPrivacy, maxLines = 1)
                }
                OutlinedButton(
                    onClick = onOpenHelp,
                    border = BorderStroke(1.dp, NebulaSilver.copy(alpha = 0.4f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NebulaSilver),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("settings_help_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.HelpOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.navHelp, maxLines = 1)
                }
            }

            // Sign Out & Account Deletion
            OutlinedButton(
                onClick = onSignOut,
                border = BorderStroke(1.dp, NebulaSilver.copy(alpha = 0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = StarlightWhite),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("settings_sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(strings.settingsSignOut)
            }

            OutlinedButton(
                onClick = { showDeleteDialog = true },
                border = BorderStroke(1.dp, CoralError.copy(alpha = 0.65f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CoralError),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("settings_delete_account_button")
            ) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(strings.settingsDeleteAccount)
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = StellarDeepNavy,
            title = { Text(strings.settingsDeleteDialogTitle, color = StarlightWhite) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(strings.settingsDeleteDialogBody, color = NebulaSilver)
                    OutlinedTextField(
                        value = deleteReason,
                        onValueChange = { deleteReason = it },
                        label = { Text(strings.settingsDeleteReasonLabel) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        onSubmitAccountDeletion(deleteReason)
                    }
                ) {
                    Text(strings.confirmLabel, color = CoralError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(strings.cancelLabel, color = NebulaSilver)
                }
            }
        )
    }
}

@Composable
private fun ConsentSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = StarlightWhite)
            if (subtitle.isNotBlank()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MutedStarlight)
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = StarlightWhite,
                checkedTrackColor = ElectricBlue
            )
        )
    }
}
