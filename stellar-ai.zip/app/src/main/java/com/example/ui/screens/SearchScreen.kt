package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.i18n.LocalAppStrings
import com.example.domain.model.UiState
import com.example.ui.components.GlassCard
import com.example.ui.components.StellarGradientButton
import com.example.ui.components.StellarTopBar
import com.example.ui.theme.CoralError
import com.example.ui.theme.CosmicViolet
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.MutedStarlight
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarGlassBorderStart
import com.example.ui.theme.StellarNavySurface
import com.example.ui.viewmodel.SearchUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    uiState: SearchUiState,
    onQueryChanged: (String) -> Unit,
    onSearch: (String?) -> Unit,
    onContinueInChat: (String) -> Unit
) {
    val strings = LocalAppStrings.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 780.dp)
    ) {
        StellarTopBar(
            title = strings.searchTitle,
            subtitle = strings.searchSubtitle
        )

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                OutlinedTextField(
                    value = uiState.query,
                    onValueChange = onQueryChanged,
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = null,
                            tint = ElectricBlue
                        )
                    },
                    placeholder = {
                        Text(strings.searchInputPlaceholder, color = MutedStarlight)
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = StellarGlassBorderStart.copy(alpha = 0.4f),
                        focusedContainerColor = StellarNavySurface,
                        unfocusedContainerColor = StellarNavySurface,
                        focusedTextColor = StarlightWhite,
                        unfocusedTextColor = StarlightWhite
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_search_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                StellarGradientButton(
                    text = strings.searchButton,
                    enabled = uiState.query.isNotBlank(),
                    isLoading = uiState.resultState is UiState.Loading,
                    onClick = { onSearch(null) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = StarlightWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_search_submit_button")
                )
            }

            item {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    strings.searchTopics.forEach { topic ->
                        AssistChip(
                            onClick = { onSearch(topic) },
                            label = { Text(topic, color = NebulaSilver) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = StellarNavySurface
                            )
                        )
                    }
                }
            }

            when (val res = uiState.resultState) {
                null -> {
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = strings.searchEmptyHint,
                                style = MaterialTheme.typography.bodyMedium,
                                color = NebulaSilver
                            )
                        }
                    }
                }

                is UiState.Loading -> {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = ElectricBlue)
                        }
                    }
                }

                is UiState.Error -> {
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(res.message, color = CoralError)
                        }
                    }
                }

                is UiState.Success -> {
                    val data = res.data
                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Column {
                                Text(
                                    text = strings.searchSummaryHeader,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ElectricBlue
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = data.summary,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = StarlightWhite
                                )
                            }
                        }
                    }

                    item {
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = strings.searchTakeawaysHeader,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CosmicViolet
                                )
                                data.keyTakeaways.forEach { item ->
                                    Row(verticalAlignment = Alignment.Top) {
                                        Icon(
                                            imageVector = Icons.Rounded.CheckCircleOutline,
                                            contentDescription = null,
                                            tint = EmeraldSuccess,
                                            modifier = Modifier
                                                .padding(top = 2.dp)
                                                .size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = item,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = StarlightWhite
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text(
                            text = strings.searchFollowUpHeader,
                            style = MaterialTheme.typography.titleMedium,
                            color = StarlightWhite
                        )
                    }

                    data.followUpQuestions.forEach { followUp ->
                        item {
                            GlassCard(
                                onClick = { onContinueInChat(followUp) },
                                contentPadding = PaddingValues(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = followUp,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = NebulaSilver,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                                        contentDescription = strings.searchAskInChat,
                                        tint = ElectricBlue
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
