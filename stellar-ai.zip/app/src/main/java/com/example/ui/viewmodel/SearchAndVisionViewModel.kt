package com.example.ui.viewmodel

import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.i18n.AppLanguage
import com.example.data.repository.AiRepository
import com.example.data.repository.FirestoreRepository
import com.example.domain.model.AiSearchResult
import com.example.domain.model.AssistantMode
import com.example.domain.model.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SearchUiState(
    val query: String = "",
    val resultState: UiState<AiSearchResult>? = null
)

class SearchViewModel(
    private val aiRepo: AiRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    fun onQueryChanged(query: String) {
        _uiState.update { it.copy(query = query) }
    }

    fun runSearch(language: AppLanguage, overrideQuery: String? = null) {
        val query = (overrideQuery ?: _uiState.value.query).trim()
        if (query.isEmpty()) return
        _uiState.update { it.copy(query = query, resultState = UiState.Loading) }
        viewModelScope.launch {
            val result = aiRepo.searchStructured(query, language)
            _uiState.update { state ->
                state.copy(
                    resultState = result.fold(
                        onSuccess = { UiState.Success(it) },
                        onFailure = { UiState.Error(it.localizedMessage ?: "Search failed") }
                    )
                )
            }
        }
    }
}

data class VisionUiState(
    val selectedUri: Uri? = null,
    val selectedBitmap: Bitmap? = null,
    val prompt: String = "",
    val analysisState: UiState<String>? = null
)

class ImageAnalysisViewModel(
    private val aiRepo: AiRepository,
    private val firestoreRepo: FirestoreRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(VisionUiState())
    val uiState: StateFlow<VisionUiState> = _uiState.asStateFlow()

    fun onImagePicked(uri: Uri, bitmap: Bitmap) {
        _uiState.update {
            it.copy(
                selectedUri = uri,
                selectedBitmap = bitmap,
                analysisState = null
            )
        }
    }

    fun onPromptChanged(prompt: String) {
        _uiState.update { it.copy(prompt = prompt) }
    }

    fun analyze(language: AppLanguage, overridePrompt: String? = null) {
        val bitmap = _uiState.value.selectedBitmap ?: return
        val prompt = (overridePrompt ?: _uiState.value.prompt).trim()
        if (overridePrompt != null) {
            _uiState.update { it.copy(prompt = prompt) }
        }
        _uiState.update { it.copy(analysisState = UiState.Loading) }
        viewModelScope.launch {
            val result = aiRepo.analyzeImage(bitmap, prompt, language)
            _uiState.update { state ->
                state.copy(
                    analysisState = result.fold(
                        onSuccess = { UiState.Success(it) },
                        onFailure = { UiState.Error(it.localizedMessage ?: "Analysis failed") }
                    )
                )
            }
        }
    }

    suspend fun saveResultAsConversation(language: AppLanguage): Result<String> {
        val state = _uiState.value
        val resultText = (state.analysisState as? UiState.Success)?.data
            ?: return Result.failure(IllegalStateException("No analysis result to save"))
        val title = state.prompt.ifBlank {
            if (language == AppLanguage.THAI) "ผลวิเคราะห์รูปภาพ" else "Image Analysis"
        }.take(64)

        val createResult = firestoreRepo.createConversationWithInitialMessage(
            userId = currentUserId,
            title = title,
            mode = AssistantMode.VISION,
            initialRole = "user",
            initialContent = state.prompt.ifBlank { title },
            hasImage = true,
            attachmentLabel = state.selectedUri?.lastPathSegment ?: "Photo"
        )
        if (createResult.isFailure) return createResult
        val convId = createResult.getOrThrow()
        val appendResult = firestoreRepo.appendMessage(
            userId = currentUserId,
            conversationId = convId,
            role = "assistant",
            content = resultText
        )
        return if (appendResult.isSuccess) Result.success(convId) else Result.failure(
            appendResult.exceptionOrNull() ?: IllegalStateException("Failed to save AI reply")
        )
    }
}
