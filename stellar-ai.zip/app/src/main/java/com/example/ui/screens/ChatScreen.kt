package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.StopCircle
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.domain.model.ChatMessage
import com.example.ui.components.GlassCard
import com.example.ui.components.StellarAvatar
import com.example.ui.components.StellarTopBar
import com.example.ui.theme.CoralError
import com.example.ui.theme.CoralErrorContainer
import com.example.ui.theme.CosmicViolet
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedStarlight
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarAITheme
import com.example.ui.theme.StellarDeepNavy
import com.example.ui.theme.StellarGlassBorderStart
import com.example.ui.theme.StellarGlassFill
import com.example.ui.theme.StellarNavyElevated
import com.example.ui.theme.StellarNavySurface
import com.example.ui.viewmodel.ChatUiState
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    uiState: ChatUiState,
    messages: List<ChatMessage>,
    customAvatarUri: String?,
    currentLanguage: AppLanguage,
    onInputChanged: (String) -> Unit,
    onSend: () -> Unit,
    onStopGeneration: () -> Unit,
    onRegenerate: () -> Unit,
    onNewChat: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenVision: () -> Unit,
    onRetryFailed: (String) -> Unit,
    onUseStarterPrompt: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    val clipboard = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, uiState.streamingReply.length) {
        val total = messages.size + if (uiState.isGenerating) 1 else 0
        if (total > 0) {
            listState.animateScrollToItem(total - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 820.dp)
                .align(Alignment.Center)
        ) {
            StellarTopBar(
                title = strings.assistantName,
                subtitle = strings.chatBackendBadge,
                actions = {
                    IconButton(
                        onClick = onOpenHistory,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("chat_history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.History,
                            contentDescription = strings.navHistory,
                            tint = NebulaSilver
                        )
                    }
                    IconButton(
                        onClick = onNewChat,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("chat_new_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AddComment,
                            contentDescription = strings.chatNewChat,
                            tint = ElectricBlue
                        )
                    }
                }
            )

            // Message List or Empty State
            if (messages.isEmpty() && !uiState.isGenerating) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    StellarAvatar(
                        customAvatarUri = customAvatarUri,
                        size = 88.dp,
                        showPulseRing = true
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = strings.chatEmptyTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = StarlightWhite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = strings.chatEmptySubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = NebulaSilver,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    strings.homePromptStarters.take(2).forEach { starter ->
                        GlassCard(
                            onClick = { onUseStarterPrompt(starter.prompt) },
                            contentPadding = PaddingValues(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                        ) {
                            Text(
                                text = starter.title,
                                style = MaterialTheme.typography.labelLarge,
                                color = ElectricBlue
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        val isLastAssistant = msg.fromAssistant &&
                            messages.lastOrNull()?.id == msg.id &&
                            !uiState.isGenerating

                        ChatBubbleRow(
                            message = msg,
                            customAvatarUri = customAvatarUri,
                            showActions = msg.fromAssistant,
                            showRegenerate = isLastAssistant,
                            onCopy = {
                                clipboard.setText(AnnotatedString(msg.content))
                                scope.launch {
                                    snackbarHostState.showSnackbar(strings.copiedNotice)
                                }
                            },
                            onRegenerate = onRegenerate
                        )
                    }

                    if (uiState.isGenerating) {
                        item(key = "streaming_bubble") {
                            StreamingAssistantBubble(
                                streamingText = uiState.streamingReply,
                                customAvatarUri = customAvatarUri,
                                thinkingLabel = strings.chatThinking,
                                streamingLabel = strings.chatStreamingLabel
                            )
                        }
                    }
                }
            }

            // Error Banner
            AnimatedVisibility(visible = !uiState.errorMessage.isNullOrBlank()) {
                Surface(
                    color = CoralErrorContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = uiState.errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = CoralError,
                            modifier = Modifier.weight(1f)
                        )
                        val failed = uiState.lastFailedPrompt
                        if (!failed.isNullOrBlank()) {
                            TextButton(onClick = { onRetryFailed(failed) }) {
                                Text(strings.retryLabel, color = StarlightWhite)
                            }
                        }
                    }
                }
            }

            // Stop Generation Pill
            AnimatedVisibility(visible = uiState.isGenerating) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    OutlinedButton(
                        onClick = onStopGeneration,
                        border = BorderStroke(1.dp, CoralError.copy(alpha = 0.65f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = StellarDeepNavy,
                            contentColor = CoralError
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("chat_stop_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.StopCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.chatStopGeneration)
                    }
                }
            }

            // Input Composer
            Surface(
                color = StellarNavySurface,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                border = BorderStroke(1.dp, StellarGlassBorderStart.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    IconButton(
                        onClick = onOpenVision,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("chat_attach_vision_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ImageSearch,
                            contentDescription = strings.navVision,
                            tint = NebulaSilver
                        )
                    }

                    OutlinedTextField(
                        value = uiState.inputText,
                        onValueChange = onInputChanged,
                        placeholder = {
                            Text(
                                text = strings.chatInputPlaceholder,
                                color = MutedStarlight
                            )
                        },
                        maxLines = 4,
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = Color.Transparent,
                            focusedContainerColor = StellarDeepNavy,
                            unfocusedContainerColor = StellarDeepNavy,
                            focusedTextColor = StarlightWhite,
                            unfocusedTextColor = StarlightWhite
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    val canSend = uiState.inputText.isNotBlank() && !uiState.isGenerating
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    if (canSend) listOf(ElectricBlue, CosmicViolet)
                                    else listOf(StellarNavyElevated, StellarNavyElevated)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = onSend,
                            enabled = canSend,
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("chat_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                contentDescription = strings.chatSendCd,
                                tint = if (canSend) StarlightWhite else MutedStarlight
                            )
                        }
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 86.dp)
        )
    }
}

@Composable
private fun ChatBubbleRow(
    message: ChatMessage,
    customAvatarUri: String?,
    showActions: Boolean,
    showRegenerate: Boolean,
    onCopy: () -> Unit,
    onRegenerate: () -> Unit
) {
    val strings = LocalAppStrings.current
    if (!message.fromAssistant) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Box(
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .clip(RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp))
                    .background(
                        Brush.linearGradient(listOf(ElectricBlue.copy(alpha = 0.28f), CosmicViolet.copy(alpha = 0.35f)))
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = StarlightWhite
                )
            }
        }
    } else {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            StellarAvatar(customAvatarUri = customAvatarUri, size = 34.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Surface(
                    color = StellarGlassFill,
                    shape = RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp),
                    border = BorderStroke(1.dp, StellarGlassBorderStart.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyLarge,
                        color = StarlightWhite,
                        modifier = Modifier.padding(14.dp)
                    )
                }
                if (showActions) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onCopy) {
                            Icon(
                                imageVector = Icons.Rounded.ContentCopy,
                                contentDescription = null,
                                tint = MutedStarlight,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.chatCopy, style = MaterialTheme.typography.labelSmall, color = MutedStarlight)
                        }
                        if (showRegenerate) {
                            TextButton(onClick = onRegenerate) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = null,
                                    tint = ElectricBlue,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(strings.chatRegenerate, style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamingAssistantBubble(
    streamingText: String,
    customAvatarUri: String?,
    thinkingLabel: String,
    streamingLabel: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        StellarAvatar(customAvatarUri = customAvatarUri, size = 34.dp, showPulseRing = true)
        Spacer(modifier = Modifier.width(10.dp))
        Surface(
            color = StellarGlassFill,
            shape = RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp),
            border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.6f)),
            modifier = Modifier.weight(1f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (streamingText.isEmpty()) thinkingLabel else streamingLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricBlue
                )
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    color = ElectricBlue,
                    trackColor = StellarNavyElevated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                )
                if (streamingText.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = streamingText,
                        style = MaterialTheme.typography.bodyLarge,
                        color = StarlightWhite
                    )
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun ChatScreenPreview() {
    StellarAITheme(language = AppLanguage.THAI) {
        Box(modifier = Modifier.background(StellarDeepNavy)) {
            ChatScreen(
                uiState = ChatUiState(),
                messages = listOf(
                    ChatMessage(id = "1", role = "user", content = "สวัสดี Stellar AI"),
                    ChatMessage(id = "2", role = "assistant", content = "สวัสดีค่ะ มีอะไรให้สเตลลาร์ช่วยวันนี้คะ?")
                ),
                customAvatarUri = null,
                currentLanguage = AppLanguage.THAI,
                onInputChanged = {},
                onSend = {},
                onStopGeneration = {},
                onRegenerate = {},
                onNewChat = {},
                onOpenHistory = {},
                onOpenVision = {},
                onRetryFailed = {},
                onUseStarterPrompt = {}
            )
        }
    }
}
