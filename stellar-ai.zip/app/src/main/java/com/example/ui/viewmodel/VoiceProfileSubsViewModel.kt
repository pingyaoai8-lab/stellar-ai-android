package com.example.ui.viewmodel

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.AppStrings
import com.example.data.repository.AiRepository
import com.example.data.repository.FirestoreRepository
import com.example.data.repository.SubscriptionRepository
import com.example.data.repository.UserPreferencesRepository
import com.example.domain.model.BillingConfigState
import com.example.domain.model.EntitlementState
import com.example.domain.model.SubscriptionPlan
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class VoicePhase {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

data class VoiceUiState(
    val phase: VoicePhase = VoicePhase.IDLE,
    val transcript: String = "",
    val fallbackInput: String = "",
    val reply: String = "",
    val errorMessage: String? = null
)

class VoiceAssistantViewModel(
    private val aiRepo: AiRepository,
    private val prefsRepo: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VoiceUiState())
    val uiState: StateFlow<VoiceUiState> = _uiState.asStateFlow()

    fun setListening(listening: Boolean) {
        _uiState.update {
            it.copy(
                phase = if (listening) VoicePhase.LISTENING else VoicePhase.IDLE,
                errorMessage = null
            )
        }
    }

    fun setSpeaking(speaking: Boolean) {
        _uiState.update {
            it.copy(phase = if (speaking) VoicePhase.SPEAKING else VoicePhase.IDLE)
        }
    }

    fun onFallbackInputChanged(text: String) {
        _uiState.update { it.copy(fallbackInput = text, errorMessage = null) }
    }

    fun submitTranscript(
        transcript: String,
        language: AppLanguage,
        onSpeakReply: (String) -> Unit
    ) {
        val clean = transcript.trim()
        if (clean.isEmpty()) {
            _uiState.update { it.copy(phase = VoicePhase.IDLE) }
            return
        }
        _uiState.update {
            it.copy(
                phase = VoicePhase.THINKING,
                transcript = clean,
                fallbackInput = "",
                errorMessage = null
            )
        }
        viewModelScope.launch {
            val result = aiRepo.voiceReply(clean, language)
            result.fold(
                onSuccess = { replyText ->
                    _uiState.update {
                        it.copy(
                            phase = VoicePhase.SPEAKING,
                            reply = replyText
                        )
                    }
                    onSpeakReply(replyText)
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            phase = VoicePhase.IDLE,
                            errorMessage = err.localizedMessage ?: "Voice processing failed"
                        )
                    }
                }
            )
        }
    }

    fun setVoiceError(message: String) {
        _uiState.update { it.copy(phase = VoicePhase.IDLE, errorMessage = message) }
    }

    fun toggleVoiceAutoSpeak(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setVoiceAutoSpeak(enabled)
        }
    }
}

class ProfileSettingsViewModel(
    private val firestoreRepo: FirestoreRepository,
    private val prefsRepo: UserPreferencesRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    fun updateDisplayName(name: String, savedText: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            _isSaving.value = true
            val res = firestoreRepo.updateUserProfile(
                userId = currentUserId,
                displayName = clean
            )
            _isSaving.value = false
            _statusMessage.value = if (res.isSuccess) savedText else {
                res.exceptionOrNull()?.localizedMessage ?: "Update failed"
            }
        }
    }

    fun updateCustomAvatar(uriString: String?, savedText: String) {
        viewModelScope.launch {
            prefsRepo.setCustomAvatarUri(uriString)
            val preset = if (uriString.isNullOrBlank()) "stellar_default" else "custom"
            firestoreRepo.updateUserProfile(
                userId = currentUserId,
                avatarPreset = preset,
                customAvatarUri = uriString
            )
            _statusMessage.value = savedText
        }
    }

    fun setAnalyticsConsent(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setAnalyticsConsent(enabled)
            firestoreRepo.updateUserProfile(
                userId = currentUserId,
                analyticsConsent = enabled
            )
        }
    }

    fun setMemoryConsent(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setMemoryConsent(enabled)
            firestoreRepo.updateUserProfile(
                userId = currentUserId,
                memoryConsent = enabled
            )
        }
    }

    fun setVoiceAutoSpeak(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setVoiceAutoSpeak(enabled)
        }
    }

    fun submitAccountDeletion(
        reason: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _isSaving.value = true
            val result = firestoreRepo.submitAccountDeletionRequest(currentUserId, reason)
            _isSaving.value = false
            if (result.isSuccess) {
                onComplete()
            } else {
                _statusMessage.value = result.exceptionOrNull()?.localizedMessage
                    ?: "Could not submit deletion request"
            }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}

class SubscriptionViewModel(
    private val subscriptionRepo: SubscriptionRepository
) : ViewModel() {

    val billingConfigState: StateFlow<BillingConfigState> = subscriptionRepo.billingConfigState
    val entitlementState: StateFlow<EntitlementState> = subscriptionRepo.entitlementState

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    fun getPlans(strings: AppStrings): List<SubscriptionPlan> =
        subscriptionRepo.getAvailablePlans(strings)

    fun onSelectPlan(activity: Activity?, plan: SubscriptionPlan, notConfiguredFallback: String) {
        viewModelScope.launch {
            val result = subscriptionRepo.initiatePurchase(activity, plan)
            if (result.isFailure) {
                _feedbackMessage.value = notConfiguredFallback
            }
        }
    }

    fun onRestorePurchases(notConfiguredFallback: String) {
        viewModelScope.launch {
            val result = subscriptionRepo.restorePurchases()
            if (result.isFailure) {
                _feedbackMessage.value = notConfiguredFallback
            }
        }
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }
}
