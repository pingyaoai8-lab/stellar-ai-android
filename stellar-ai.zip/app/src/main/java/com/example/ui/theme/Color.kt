package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Cosmic Dark Navy & Obsidian Surfaces
val StellarObsidian = Color(0xFF050814)
val StellarDeepNavy = Color(0xFF090F24)
val StellarNavySurface = Color(0xFF0E1733)
val StellarNavyElevated = Color(0xFF142044)
val StellarGlassFill = Color(0xCC111B38)
val StellarGlassBorderStart = Color(0x8038BDF8)
val StellarGlassBorderEnd = Color(0x808B5CF6)

// Accents: Electric Blue & Cosmic Violet
val ElectricBlue = Color(0xFF38BDF8)
val ElectricBlueBright = Color(0xFF60A5FA)
val CosmicViolet = Color(0xFF8B5CF6)
val CosmicVioletDeep = Color(0xFF6D28D9)
val IndigoNebula = Color(0xFF6366F1)

// Accessible High-Contrast Text & Semantic Status
val StarlightWhite = Color(0xFFF8FAFC)
val NebulaSilver = Color(0xFFCBD5E1)
val MutedStarlight = Color(0xFF94A3B8)
val SubtleDivider = Color(0x3364748B)

val EmeraldSuccess = Color(0xFF34D399)
val AmberWarning = Color(0xFFFBBF24)
val CoralError = Color(0xFFF87171)
val CoralErrorContainer = Color(0x33EF4444)
