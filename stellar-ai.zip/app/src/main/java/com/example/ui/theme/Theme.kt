package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.unit.dp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.core.i18n.stringsFor

private val StellarDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = StellarObsidian,
    primaryContainer = StellarNavyElevated,
    onPrimaryContainer = StarlightWhite,
    secondary = CosmicViolet,
    onSecondary = StarlightWhite,
    secondaryContainer = CosmicVioletDeep,
    onSecondaryContainer = StarlightWhite,
    tertiary = IndigoNebula,
    onTertiary = StarlightWhite,
    background = StellarObsidian,
    onBackground = StarlightWhite,
    surface = StellarDeepNavy,
    onSurface = StarlightWhite,
    surfaceVariant = StellarNavySurface,
    onSurfaceVariant = NebulaSilver,
    outline = StellarGlassBorderStart,
    outlineVariant = SubtleDivider,
    error = CoralError,
    onError = StellarObsidian,
    errorContainer = CoralErrorContainer,
    onErrorContainer = StarlightWhite
)

private val StellarShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun StellarAITheme(
    language: AppLanguage = AppLanguage.THAI,
    content: @Composable () -> Unit
) {
    val strings = stringsFor(language)
    val typography = buildStellarTypography(language)

    CompositionLocalProvider(LocalAppStrings provides strings) {
        MaterialTheme(
            colorScheme = StellarDarkColorScheme,
            typography = typography,
            shapes = StellarShapes,
            content = content
        )
    }
}
