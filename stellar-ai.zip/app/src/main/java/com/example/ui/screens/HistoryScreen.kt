package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.i18n.LocalAppStrings
import com.example.domain.model.Conversation
import com.example.domain.model.UiState
import com.example.ui.components.GlassCard
import com.example.ui.components.StellarTopBar
import com.example.ui.theme.CoralError
import com.example.ui.theme.CosmicViolet
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedStarlight
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarDeepNavy
import com.example.ui.theme.StellarGlassBorderStart
import com.example.ui.theme.StellarNavySurface

@Composable
fun HistoryScreen(
    searchQuery: String,
    conversationsState: UiState<List<Conversation>>,
    onSearchQueryChanged: (String) -> Unit,
    onOpenConversation: (String) -> Unit,
    onTogglePin: (Conversation) -> Unit,
    onDeleteConversation: (String) -> Unit
) {
    val strings = LocalAppStrings.current
    var pendingDelete by remember { mutableStateOf<Conversation?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 780.dp)
    ) {
        StellarTopBar(title = strings.historyTitle)

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChanged,
            singleLine = true,
            leadingIcon = {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = null,
                    tint = ElectricBlue
                )
            },
            placeholder = {
                Text(strings.historySearchPlaceholder, color = MutedStarlight)
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElectricBlue,
                unfocusedBorderColor = StellarGlassBorderStart.copy(alpha = 0.4f),
                focusedContainerColor = StellarNavySurface,
                unfocusedContainerColor = StellarNavySurface,
                focusedTextColor = StarlightWhite,
                unfocusedTextColor = StarlightWhite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp)
                .testTag("history_search_input")
        )

        when (conversationsState) {
            is UiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = ElectricBlue)
                }
            }

            is UiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    GlassCard {
                        Text(conversationsState.message, color = CoralError)
                    }
                }
            }

            is UiState.Success -> {
                val list = conversationsState.data
                val pinned = list.filter { it.pinned }
                val regular = list.filterNot { it.pinned }

                if (list.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Forum,
                            contentDescription = null,
                            tint = ElectricBlue.copy(alpha = 0.7f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = strings.historyEmptyTitle,
                            style = MaterialTheme.typography.titleLarge,
                            color = StarlightWhite
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = strings.historyEmptySubtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = NebulaSilver
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (pinned.isNotEmpty()) {
                            item {
                                Text(
                                    text = strings.historyPinnedSection,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = ElectricBlue
                                )
                            }
                            items(pinned, key = { "pin_${it.id}" }) { conv ->
                                ConversationHistoryCard(
                                    conversation = conv,
                                    onClick = { onOpenConversation(conv.id) },
                                    onTogglePin = { onTogglePin(conv) },
                                    onRequestDelete = { pendingDelete = conv }
                                )
                            }
                        }

                        if (regular.isNotEmpty()) {
                            item {
                                Text(
                                    text = strings.historyAllSection,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = NebulaSilver,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                            items(regular, key = { it.id }) { conv ->
                                ConversationHistoryCard(
                                    conversation = conv,
                                    onClick = { onOpenConversation(conv.id) },
                                    onTogglePin = { onTogglePin(conv) },
                                    onRequestDelete = { pendingDelete = conv }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDelete?.let { conv ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            containerColor = StellarDeepNavy,
            title = { Text(strings.historyDeleteTitle, color = StarlightWhite) },
            text = { Text(strings.historyDeleteBody, color = NebulaSilver) },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteConversation(conv.id)
                        pendingDelete = null
                    }
                ) {
                    Text(strings.historyDelete, color = CoralError)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text(strings.cancelLabel, color = NebulaSilver)
                }
            }
        )
    }
}

@Composable
private fun ConversationHistoryCard(
    conversation: Conversation,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onRequestDelete: () -> Unit
) {
    val strings = LocalAppStrings.current
    GlassCard(
        onClick = onClick,
        contentPadding = PaddingValues(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = CosmicViolet.copy(alpha = 0.22f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = conversation.mode.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricBlue,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${conversation.messageCount} msgs",
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedStarlight
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = conversation.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = StarlightWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = conversation.lastMessagePreview,
                    style = MaterialTheme.typography.bodySmall,
                    color = NebulaSilver,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onTogglePin,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.Rounded.PushPin,
                    contentDescription = if (conversation.pinned) strings.historyUnpin else strings.historyPin,
                    tint = if (conversation.pinned) ElectricBlue else MutedStarlight
                )
            }
            IconButton(
                onClick = onRequestDelete,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = strings.historyDelete,
                    tint = CoralError.copy(alpha = 0.85f)
                )
            }
        }
    }
}
