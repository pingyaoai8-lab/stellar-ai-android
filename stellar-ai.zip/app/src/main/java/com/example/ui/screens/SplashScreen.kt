package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.ui.components.CosmicBackground
import com.example.ui.components.StellarAvatar
import com.example.ui.theme.CosmicViolet
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.ui.theme.StellarAITheme
import com.example.ui.theme.StellarNavySurface
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    customAvatarUri: String?,
    onFinished: () -> Unit
) {
    val strings = LocalAppStrings.current
    var reveal by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        reveal = true
        delay(1300L)
        onFinished()
    }

    val scale by animateFloatAsState(
        targetValue = if (reveal) 1f else 0.88f,
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label = "splash_scale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (reveal) 1f else 0f,
        animationSpec = tween(700),
        label = "splash_alpha"
    )

    CosmicBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(32.dp)
                .alpha(alpha)
                .scale(scale),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            StellarAvatar(
                customAvatarUri = customAvatarUri,
                size = 132.dp,
                showPulseRing = true
            )
            Spacer(modifier = Modifier.height(28.dp))
            Text(
                text = strings.brandName,
                style = TextStyle(
                    fontFamily = SpaceGroteskFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 34.sp,
                    letterSpacing = 4.sp,
                    brush = Brush.horizontalGradient(listOf(ElectricBlue, CosmicViolet))
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = strings.tagline,
                style = MaterialTheme.typography.titleMedium,
                color = NebulaSilver
            )
            Spacer(modifier = Modifier.height(32.dp))
            LinearProgressIndicator(
                color = ElectricBlue,
                trackColor = StellarNavySurface,
                modifier = Modifier.height(3.dp)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun SplashScreenPreview() {
    StellarAITheme(language = AppLanguage.THAI) {
        SplashScreen(customAvatarUri = null, onFinished = {})
    }
}
