package com.example.ui.navigation

import android.app.Application
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.core.firebase.signOutUser
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.data.repository.FirebaseAiRepository
import com.example.data.repository.FirestoreRepository
import com.example.data.repository.LocalAppPreferences
import com.example.data.repository.PlayBillingSubscriptionRepository
import com.example.data.repository.UserPreferencesRepository
import com.example.domain.model.UiState
import com.example.domain.model.UserProfile
import com.example.ui.components.CosmicBackground
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HelpScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageAnalysisScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PrivacyPolicyScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SubscriptionScreen
import com.example.ui.screens.VoiceAssistantScreen
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedStarlight
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarDeepNavy
import com.example.ui.theme.StellarNavyElevated
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.HistoryAndHomeViewModel
import com.example.ui.viewmodel.ImageAnalysisViewModel
import com.example.ui.viewmodel.ProfileSettingsViewModel
import com.example.ui.viewmodel.SearchViewModel
import com.example.ui.viewmodel.SessionViewModel
import com.example.ui.viewmodel.SubscriptionViewModel
import com.example.ui.viewmodel.VoiceAssistantViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

object StellarRoutes {
    const val HOME = "home"
    const val CHAT = "chat"
    const val SEARCH = "search"
    const val VISION = "vision"
    const val HISTORY = "history"
    const val VOICE = "voice"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val SUBSCRIPTIONS = "subscriptions"
    const val PRIVACY = "privacy"
    const val HELP = "help"
}

private enum class UnauthOverlay {
    NONE,
    PRIVACY,
    HELP
}

private data class TopNavItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val tag: String
)

@Composable
fun StellarAppRoot(
    sessionViewModel: SessionViewModel
) {
    val splashFinished by sessionViewModel.splashFinished.collectAsStateWithLifecycle()
    val localPrefs by sessionViewModel.localPreferences.collectAsStateWithLifecycle()
    val currentUser by sessionViewModel.currentUser.collectAsStateWithLifecycle()
    val userProfile by sessionViewModel.userProfile.collectAsStateWithLifecycle()

    LaunchedEffect(currentUser?.uid) {
        currentUser?.let { sessionViewModel.onAuthenticatedUser(it) }
    }

    if (!splashFinished) {
        SplashScreen(
            customAvatarUri = localPrefs.customAvatarUri,
            onFinished = { sessionViewModel.markSplashFinished() }
        )
        return
    }

    val user = currentUser
    if (user == null) {
        if (!localPrefs.onboardingCompleted) {
            OnboardingScreen(
                currentLanguage = localPrefs.language,
                onLanguageChanged = { sessionViewModel.setLanguage(it) },
                onFinishOnboarding = { sessionViewModel.completeOnboarding() }
            )
        } else {
            var overlay by remember { mutableStateOf(UnauthOverlay.NONE) }
            when (overlay) {
                UnauthOverlay.PRIVACY -> {
                    BackHandler { overlay = UnauthOverlay.NONE }
                    CosmicBackground {
                        PrivacyPolicyScreen(
                            showAccountDeletionShortcut = false,
                            onBack = { overlay = UnauthOverlay.NONE },
                            onOpenDeleteAccount = {}
                        )
                    }
                }

                UnauthOverlay.HELP -> {
                    BackHandler { overlay = UnauthOverlay.NONE }
                    CosmicBackground {
                        HelpScreen(onBack = { overlay = UnauthOverlay.NONE })
                    }
                }

                UnauthOverlay.NONE -> {
                    AuthScreen(
                        currentLanguage = localPrefs.language,
                        onLanguageChanged = { sessionViewModel.setLanguage(it) },
                        onAuthSuccess = {},
                        onOpenPrivacyPolicy = { overlay = UnauthOverlay.PRIVACY },
                        onOpenHelp = { overlay = UnauthOverlay.HELP }
                    )
                }
            }
        }
    } else {
        key(user.uid) {
            AuthenticatedMainShell(
                uid = user.uid,
                fallbackDisplayName = user.displayName ?: user.email?.substringBefore("@") ?: "Stellar Explorer",
                fallbackEmail = user.email,
                userProfile = userProfile,
                localPrefs = localPrefs,
                onLanguageChanged = { sessionViewModel.setLanguage(it) }
            )
        }
    }
}

@Composable
private fun AuthenticatedMainShell(
    uid: String,
    fallbackDisplayName: String,
    fallbackEmail: String?,
    userProfile: UserProfile?,
    localPrefs: LocalAppPreferences,
    onLanguageChanged: (AppLanguage) -> Unit
) {
    val strings = LocalAppStrings.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val navController = rememberNavController()

    val aiRepo = remember { FirebaseAiRepository() }
    val subsRepo = remember { PlayBillingSubscriptionRepository() }

    val historyHomeVm: HistoryAndHomeViewModel = viewModel(
        key = "history_home_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                HistoryAndHomeViewModel(FirestoreRepository(db), uid)
            }
        }
    )

    val chatVm: ChatViewModel = viewModel(
        key = "chat_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                ChatViewModel(FirestoreRepository(db), aiRepo, uid)
            }
        }
    )

    val searchVm: SearchViewModel = viewModel(
        key = "search_$uid",
        factory = viewModelFactory {
            initializer { SearchViewModel(aiRepo) }
        }
    )

    val visionVm: ImageAnalysisViewModel = viewModel(
        key = "vision_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                ImageAnalysisViewModel(aiRepo, FirestoreRepository(db), uid)
            }
        }
    )

    val voiceVm: VoiceAssistantViewModel = viewModel(
        key = "voice_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                VoiceAssistantViewModel(aiRepo, UserPreferencesRepository(app))
            }
        }
    )

    val profileSettingsVm: ProfileSettingsViewModel = viewModel(
        key = "profile_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                ProfileSettingsViewModel(
                    FirestoreRepository(db),
                    UserPreferencesRepository(app),
                    uid
                )
            }
        }
    )

    val subsVm: SubscriptionViewModel = viewModel(
        key = "subs_$uid",
        factory = viewModelFactory {
            initializer { SubscriptionViewModel(subsRepo) }
        }
    )

    val conversationsState by historyHomeVm.conversationsState.collectAsStateWithLifecycle()
    val filteredConversations by historyHomeVm.filteredConversations.collectAsStateWithLifecycle()
    val historySearchQuery by historyHomeVm.searchQuery.collectAsStateWithLifecycle()
    val chatUiState by chatVm.uiState.collectAsStateWithLifecycle()
    val chatMessages by chatVm.messages.collectAsStateWithLifecycle()
    val searchUiState by searchVm.uiState.collectAsStateWithLifecycle()
    val visionUiState by visionVm.uiState.collectAsStateWithLifecycle()
    val voiceUiState by voiceVm.uiState.collectAsStateWithLifecycle()
    val profileStatus by profileSettingsVm.statusMessage.collectAsStateWithLifecycle()
    val isProfileSaving by profileSettingsVm.isSaving.collectAsStateWithLifecycle()
    val billingConfigState by subsVm.billingConfigState.collectAsStateWithLifecycle()
    val subsFeedback by subsVm.feedbackMessage.collectAsStateWithLifecycle()

    var openDeleteDialogOnSettings by remember { mutableStateOf(false) }

    val topNavItems = listOf(
        TopNavItem(StellarRoutes.HOME, strings.navHome, Icons.Rounded.Home, "nav_home"),
        TopNavItem(StellarRoutes.CHAT, strings.navChat, Icons.AutoMirrored.Rounded.Chat, "nav_chat"),
        TopNavItem(StellarRoutes.SEARCH, strings.navSearch, Icons.Rounded.Search, "nav_search"),
        TopNavItem(StellarRoutes.VISION, strings.navVision, Icons.Rounded.ImageSearch, "nav_vision"),
        TopNavItem(StellarRoutes.HISTORY, strings.navHistory, Icons.Rounded.History, "nav_history")
    )
    val topRoutes = topNavItems.map { it.route }.toSet()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showTopLevelNav = currentRoute in topRoutes

    val navigateTopLevel: (String) -> Unit = { target ->
        navController.navigate(target) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val activeAvatarUri = localPrefs.customAvatarUri ?: userProfile?.customAvatarUri
    val activeDisplayName = userProfile?.displayName?.takeIf { it.isNotBlank() } ?: fallbackDisplayName

    CosmicBackground {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    if (showTopLevelNav && !useRail) {
                        NavigationBar(
                            containerColor = StellarDeepNavy.copy(alpha = 0.96f),
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            topNavItems.forEach { item ->
                                val selected = currentRoute == item.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = { Icon(item.icon, contentDescription = item.label) },
                                    label = { Text(item.label, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = ElectricBlue,
                                        selectedTextColor = ElectricBlue,
                                        indicatorColor = StellarNavyElevated,
                                        unselectedIconColor = MutedStarlight,
                                        unselectedTextColor = MutedStarlight
                                    ),
                                    modifier = Modifier.testTag(item.tag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (showTopLevelNav && useRail) {
                        NavigationRail(
                            containerColor = StellarDeepNavy.copy(alpha = 0.96f),
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            topNavItems.forEach { item ->
                                val selected = currentRoute == item.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = { Icon(item.icon, contentDescription = item.label) },
                                    label = { Text(item.label, maxLines = 1) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = ElectricBlue,
                                        selectedTextColor = ElectricBlue,
                                        indicatorColor = StellarNavyElevated,
                                        unselectedIconColor = MutedStarlight,
                                        unselectedTextColor = MutedStarlight
                                    ),
                                    modifier = Modifier.testTag(item.tag)
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        NavHost(
                            navController = navController,
                            startDestination = StellarRoutes.HOME
                        ) {
                            composable(StellarRoutes.HOME) {
                                HomeScreen(
                                    displayName = activeDisplayName,
                                    customAvatarUri = activeAvatarUri,
                                    conversationsState = conversationsState,
                                    onOpenNewChat = {
                                        chatVm.startNewChat()
                                        navigateTopLevel(StellarRoutes.CHAT)
                                    },
                                    onOpenChatWithPrompt = { prompt ->
                                        chatVm.startNewChat()
                                        chatVm.sendMessage(localPrefs.language, overridePrompt = prompt)
                                        navigateTopLevel(StellarRoutes.CHAT)
                                    },
                                    onOpenConversation = { convId ->
                                        chatVm.selectConversation(convId)
                                        navigateTopLevel(StellarRoutes.CHAT)
                                    },
                                    onOpenSearch = { navigateTopLevel(StellarRoutes.SEARCH) },
                                    onOpenVision = { navigateTopLevel(StellarRoutes.VISION) },
                                    onOpenVoice = { navController.navigate(StellarRoutes.VOICE) },
                                    onOpenHistory = { navigateTopLevel(StellarRoutes.HISTORY) },
                                    onOpenProfile = { navController.navigate(StellarRoutes.PROFILE) },
                                    onOpenSettings = {
                                        openDeleteDialogOnSettings = false
                                        navController.navigate(StellarRoutes.SETTINGS)
                                    },
                                    onOpenSubscriptions = { navController.navigate(StellarRoutes.SUBSCRIPTIONS) }
                                )
                            }

                            composable(StellarRoutes.CHAT) {
                                ChatScreen(
                                    uiState = chatUiState,
                                    messages = chatMessages,
                                    customAvatarUri = activeAvatarUri,
                                    currentLanguage = localPrefs.language,
                                    onInputChanged = { chatVm.onInputChanged(it) },
                                    onSend = { chatVm.sendMessage(localPrefs.language) },
                                    onStopGeneration = { chatVm.stopGeneration() },
                                    onRegenerate = { chatVm.regenerateLastResponse(localPrefs.language) },
                                    onNewChat = { chatVm.startNewChat() },
                                    onOpenHistory = { navigateTopLevel(StellarRoutes.HISTORY) },
                                    onOpenVision = { navigateTopLevel(StellarRoutes.VISION) },
                                    onRetryFailed = { failedPrompt ->
                                        chatVm.sendMessage(localPrefs.language, overridePrompt = failedPrompt)
                                    },
                                    onUseStarterPrompt = { prompt ->
                                        chatVm.sendMessage(localPrefs.language, overridePrompt = prompt)
                                    }
                                )
                            }

                            composable(StellarRoutes.HISTORY) {
                                HistoryScreen(
                                    searchQuery = historySearchQuery,
                                    conversationsState = filteredConversations,
                                    onSearchQueryChanged = { historyHomeVm.onSearchQueryChanged(it) },
                                    onOpenConversation = { convId ->
                                        chatVm.selectConversation(convId)
                                        navigateTopLevel(StellarRoutes.CHAT)
                                    },
                                    onTogglePin = { historyHomeVm.togglePin(it) },
                                    onDeleteConversation = { historyHomeVm.deleteConversation(it) }
                                )
                            }

                            composable(StellarRoutes.SEARCH) {
                                SearchScreen(
                                    uiState = searchUiState,
                                    onQueryChanged = { searchVm.onQueryChanged(it) },
                                    onSearch = { overrideQuery ->
                                        searchVm.runSearch(localPrefs.language, overrideQuery)
                                    },
                                    onContinueInChat = { followUp ->
                                        chatVm.startNewChat()
                                        chatVm.sendMessage(localPrefs.language, overridePrompt = followUp)
                                        navigateTopLevel(StellarRoutes.CHAT)
                                    }
                                )
                            }

                            composable(StellarRoutes.VISION) {
                                ImageAnalysisScreen(
                                    uiState = visionUiState,
                                    onImagePicked = { uri, bmp -> visionVm.onImagePicked(uri, bmp) },
                                    onPromptChanged = { visionVm.onPromptChanged(it) },
                                    onAnalyze = { presetPrompt ->
                                        visionVm.analyze(localPrefs.language, presetPrompt)
                                    },
                                    onSaveAndContinueInChat = {
                                        scope.launch {
                                            val saved = visionVm.saveResultAsConversation(localPrefs.language)
                                            saved.onSuccess { convId ->
                                                chatVm.selectConversation(convId)
                                                navigateTopLevel(StellarRoutes.CHAT)
                                            }
                                        }
                                    }
                                )
                            }

                            composable(StellarRoutes.VOICE) {
                                VoiceAssistantScreen(
                                    uiState = voiceUiState,
                                    customAvatarUri = activeAvatarUri,
                                    currentLanguage = localPrefs.language,
                                    autoSpeakEnabled = localPrefs.voiceAutoSpeak,
                                    onBack = { navController.popBackStack() },
                                    onToggleAutoSpeak = { voiceVm.toggleVoiceAutoSpeak(it) },
                                    onFallbackInputChanged = { voiceVm.onFallbackInputChanged(it) },
                                    onSubmitTranscript = { transcript, speak ->
                                        voiceVm.submitTranscript(transcript, localPrefs.language, speak)
                                    },
                                    onListeningChanged = { voiceVm.setListening(it) },
                                    onSpeakingChanged = { voiceVm.setSpeaking(it) },
                                    onVoiceError = { voiceVm.setVoiceError(it) }
                                )
                            }

                            composable(StellarRoutes.PROFILE) {
                                val count = (conversationsState as? UiState.Success)?.data?.size ?: 0
                                ProfileScreen(
                                    userProfile = userProfile,
                                    fallbackEmail = fallbackEmail,
                                    customAvatarUri = activeAvatarUri,
                                    conversationCount = count,
                                    statusMessage = profileStatus,
                                    isSaving = isProfileSaving,
                                    onBack = { navController.popBackStack() },
                                    onSaveDisplayName = {
                                        profileSettingsVm.updateDisplayName(it, strings.profileSavedNotice)
                                    },
                                    onReplaceAvatar = { uriString ->
                                        profileSettingsVm.updateCustomAvatar(uriString, strings.profileSavedNotice)
                                    },
                                    onOpenSubscriptions = { navController.navigate(StellarRoutes.SUBSCRIPTIONS) },
                                    onOpenDeleteAccount = {
                                        openDeleteDialogOnSettings = true
                                        navController.navigate(StellarRoutes.SETTINGS)
                                    },
                                    onClearStatusMessage = { profileSettingsVm.clearStatusMessage() }
                                )
                            }

                            composable(StellarRoutes.SETTINGS) {
                                SettingsScreen(
                                    preferences = localPrefs,
                                    showDeleteDialogInitial = openDeleteDialogOnSettings,
                                    onBack = {
                                        openDeleteDialogOnSettings = false
                                        navController.popBackStack()
                                    },
                                    onLanguageChanged = onLanguageChanged,
                                    onAnalyticsConsentChanged = { profileSettingsVm.setAnalyticsConsent(it) },
                                    onMemoryConsentChanged = { profileSettingsVm.setMemoryConsent(it) },
                                    onVoiceAutoSpeakChanged = { profileSettingsVm.setVoiceAutoSpeak(it) },
                                    onOpenPrivacyPolicy = { navController.navigate(StellarRoutes.PRIVACY) },
                                    onOpenHelp = { navController.navigate(StellarRoutes.HELP) },
                                    onSignOut = {
                                        signOutUser(credentialManager, scope)
                                    },
                                    onSubmitAccountDeletion = { reason ->
                                        profileSettingsVm.submitAccountDeletion(reason) {
                                            signOutUser(credentialManager, scope)
                                        }
                                    }
                                )
                            }

                            composable(StellarRoutes.SUBSCRIPTIONS) {
                                SubscriptionScreen(
                                    plans = subsVm.getPlans(strings),
                                    billingConfigState = billingConfigState,
                                    feedbackMessage = subsFeedback,
                                    onBack = { navController.popBackStack() },
                                    onSelectPlan = { activity, plan ->
                                        subsVm.onSelectPlan(activity, plan, strings.subsNotConfiguredMessage)
                                    },
                                    onRestorePurchases = {
                                        subsVm.onRestorePurchases(strings.subsNotConfiguredMessage)
                                    },
                                    onClearFeedback = { subsVm.clearFeedback() }
                                )
                            }

                            composable(StellarRoutes.PRIVACY) {
                                PrivacyPolicyScreen(
                                    showAccountDeletionShortcut = true,
                                    onBack = { navController.popBackStack() },
                                    onOpenDeleteAccount = {
                                        openDeleteDialogOnSettings = true
                                        navController.navigate(StellarRoutes.SETTINGS)
                                    }
                                )
                            }

                            composable(StellarRoutes.HELP) {
                                HelpScreen(onBack = { navController.popBackStack() })
                            }
                        }
                    }
                }
            }
        }
    }
}
