package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.i18n.LocalAppStrings
import com.example.domain.model.SubscriptionTier
import com.example.domain.model.UserProfile
import com.example.ui.components.GlassCard
import com.example.ui.components.StellarAvatar
import com.example.ui.components.StellarGradientButton
import com.example.ui.components.StellarTopBar
import com.example.ui.theme.CoralError
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MutedStarlight
import com.example.ui.theme.NebulaSilver
import com.example.ui.theme.StarlightWhite
import com.example.ui.theme.StellarGlassBorderStart
import com.example.ui.theme.StellarNavySurface

@Composable
fun ProfileScreen(
    userProfile: UserProfile?,
    fallbackEmail: String?,
    customAvatarUri: String?,
    conversationCount: Int,
    statusMessage: String?,
    isSaving: Boolean,
    onBack: () -> Unit,
    onSaveDisplayName: (String) -> Unit,
    onReplaceAvatar: (String?) -> Unit,
    onOpenSubscriptions: () -> Unit,
    onOpenDeleteAccount: () -> Unit,
    onClearStatusMessage: () -> Unit
) {
    val strings = LocalAppStrings.current
    val snackbarHostState = remember { SnackbarHostState() }
    var nameInput by remember(userProfile?.displayName) {
        mutableStateOf(userProfile?.displayName.orEmpty())
    }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onReplaceAvatar(uri.toString())
        }
    }

    LaunchedEffect(statusMessage) {
        if (!statusMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(statusMessage)
            onClearStatusMessage()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .align(Alignment.TopCenter)
        ) {
            StellarTopBar(
                title = strings.profileTitle,
                onBack = onBack
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Assistant Avatar Replacement Card
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        StellarAvatar(
                            customAvatarUri = customAvatarUri ?: userProfile?.customAvatarUri,
                            size = 112.dp,
                            showPulseRing = true
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = userProfile?.email ?: fallbackEmail.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedStarlight
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = strings.profileAvatarHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = NebulaSilver
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    avatarPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                border = BorderStroke(1.dp, ElectricBlue),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricBlue),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("profile_replace_avatar_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PhotoCamera,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(strings.profileReplaceAvatar, maxLines = 1)
                            }
                            if (!customAvatarUri.isNullOrBlank()) {
                                OutlinedButton(
                                    onClick = { onReplaceAvatar(null) },
                                    border = BorderStroke(1.dp, NebulaSilver.copy(alpha = 0.5f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NebulaSilver),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("profile_reset_avatar_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Restore,
                                        contentDescription = strings.profileResetAvatar,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Editable Name Card
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text(strings.profileDisplayNameLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricBlue,
                                unfocusedBorderColor = StellarGlassBorderStart.copy(alpha = 0.4f),
                                focusedContainerColor = StellarNavySurface,
                                unfocusedContainerColor = StellarNavySurface,
                                focusedTextColor = StarlightWhite,
                                unfocusedTextColor = StarlightWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("profile_name_input")
                        )
                        StellarGradientButton(
                            text = strings.saveLabel,
                            isLoading = isSaving,
                            enabled = nameInput.isNotBlank(),
                            onClick = { onSaveDisplayName(nameInput) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("profile_save_button")
                        )
                    }
                }

                // Membership & Stats Card
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(strings.profileStatsConversations, color = NebulaSilver)
                            Text(
                                text = conversationCount.toString(),
                                style = MaterialTheme.typography.titleMedium,
                                color = ElectricBlue
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(strings.profileTierLabel, color = NebulaSilver)
                            Surface(
                                color = ElectricBlue.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50)
                            ) {
                                val tierText = when (userProfile?.tierEnum ?: SubscriptionTier.FREE) {
                                    SubscriptionTier.FREE -> "Free"
                                    SubscriptionTier.PRO_MONTHLY -> "Pro Monthly"
                                    SubscriptionTier.PRO_YEARLY -> "Pro Yearly"
                                }
                                Text(
                                    text = tierText,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ElectricBlue,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                )
                            }
                        }
                        OutlinedButton(
                            onClick = onOpenSubscriptions,
                            border = BorderStroke(1.dp, ElectricBlue.copy(alpha = 0.7f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricBlue),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("profile_upgrade_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WorkspacePremium,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.profileUpgradeCta)
                        }
                    }
                }

                TextButton(
                    onClick = onOpenDeleteAccount,
                    modifier = Modifier.testTag("profile_delete_account_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteForever,
                        contentDescription = null,
                        tint = CoralError,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.profileDeleteAccountCta, color = CoralError)
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}
