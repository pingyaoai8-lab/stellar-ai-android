package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.firebase.authStateFlow
import com.example.core.i18n.AppLanguage
import com.example.data.repository.FirestoreRepository
import com.example.data.repository.LocalAppPreferences
import com.example.data.repository.UserPreferencesRepository
import com.example.domain.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class SessionViewModel(
    private val prefsRepo: UserPreferencesRepository,
    private val firestoreRepo: FirestoreRepository,
    auth: FirebaseAuth = Firebase.auth
) : ViewModel() {

    private val _splashFinished = MutableStateFlow(false)
    val splashFinished: StateFlow<Boolean> = _splashFinished.asStateFlow()

    val localPreferences: StateFlow<LocalAppPreferences> = prefsRepo.preferences
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = LocalAppPreferences()
        )

    val currentUser: StateFlow<FirebaseUser?> = auth.authStateFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = auth.currentUser
        )

    val userProfile: StateFlow<UserProfile?> = currentUser
        .flatMapLatest { user ->
            if (user == null) {
                flowOf(null)
            } else {
                firestoreRepo.observeUserProfile(user.uid)
                    .catch { error ->
                        val firestoreError = generateSequence(error) { it.cause }
                            .filterIsInstance<FirebaseFirestoreException>()
                            .firstOrNull()
                        if (firestoreError == null && error is CancellationException) throw error
                        emit(null)
                    }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = null
        )

    fun markSplashFinished() {
        _splashFinished.value = true
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            prefsRepo.setOnboardingCompleted(true)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsRepo.setLanguage(language)
            currentUser.value?.uid?.let { uid ->
                firestoreRepo.updateUserProfile(userId = uid, preferredLanguage = language)
            }
        }
    }

    fun onAuthenticatedUser(user: FirebaseUser) {
        viewModelScope.launch {
            val lang = localPreferences.value.language
            val name = user.displayName ?: user.email?.substringBefore("@") ?: "Stellar Explorer"
            firestoreRepo.ensureUserProfile(
                userId = user.uid,
                defaultDisplayName = name,
                email = user.email,
                defaultLanguage = lang
            )
            firestoreRepo.seedSampleConversationsIfEmpty(user.uid, lang)
        }
    }
}
