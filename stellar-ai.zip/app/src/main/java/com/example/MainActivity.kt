package com.example

import android.app.Application
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.core.firebase.configureAppCheck
import com.example.data.repository.FirestoreRepository
import com.example.data.repository.UserPreferencesRepository
import com.example.ui.navigation.StellarAppRoot
import com.example.ui.theme.StellarAITheme
import com.example.ui.viewmodel.SessionViewModel
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check with launch intent before any UI, ViewModels, or Firebase operations.
        configureAppCheck(this, intent)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )

        setContent {
            val sessionViewModel: SessionViewModel = viewModel(
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY]) as Application
                        val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                        SessionViewModel(
                            prefsRepo = UserPreferencesRepository(app),
                            firestoreRepo = FirestoreRepository(db)
                        )
                    }
                }
            )
            val prefs by sessionViewModel.localPreferences.collectAsStateWithLifecycle()

            StellarAITheme(language = prefs.language) {
                StellarAppRoot(sessionViewModel = sessionViewModel)
            }
        }
    }
}
