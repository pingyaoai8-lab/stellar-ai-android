package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.core.firebase.OperationType
import com.example.core.firebase.handleFirestoreError
import com.example.core.i18n.AppLanguage
import com.example.domain.model.AssistantMode
import com.example.domain.model.ChatMessage
import com.example.domain.model.Conversation
import com.example.domain.model.SubscriptionTier
import com.example.domain.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun ensureUserProfile(
        userId: String,
        defaultDisplayName: String,
        email: String?,
        defaultLanguage: AppLanguage
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val docRef = db.collection("users").document(uid)
            val existing = docRef.get().await()
            if (!existing.exists()) {
                val safeName = defaultDisplayName.trim().ifBlank { "Stellar Explorer" }.take(80)
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("displayName", safeName)
                    if (!email.isNullOrBlank()) {
                        put("email", email.take(160))
                    }
                    put("avatarPreset", "stellar_default")
                    put("preferredLanguage", defaultLanguage.code)
                    put("analyticsConsent", false)
                    put("memoryConsent", true)
                    put("subscriptionTier", SubscriptionTier.FREE.wireValue)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserProfile(
        userId: String,
        displayName: String? = null,
        avatarPreset: String? = null,
        customAvatarUri: String? = null,
        preferredLanguage: AppLanguage? = null,
        analyticsConsent: Boolean? = null,
        memoryConsent: Boolean? = null
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            displayName?.trim()?.takeIf { it.isNotEmpty() }?.let {
                updates["displayName"] = it.take(80)
            }
            avatarPreset?.let { updates["avatarPreset"] = it }
            customAvatarUri?.takeIf { it.isNotBlank() }?.let {
                updates["customAvatarUri"] = it.take(500)
            }
            preferredLanguage?.let { updates["preferredLanguage"] = it.code }
            analyticsConsent?.let { updates["analyticsConsent"] = it }
            memoryConsent?.let { updates["memoryConsent"] = it }

            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeConversations(userId: String): Flow<List<Conversation>> = flow {
        require(userId.isNotBlank()) { "User ID must not be blank" }
        val path = "users/$userId/conversations"
        emitAll(
            db.collection("users").document(userId).collection("conversations")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Conversation::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMessages(userId: String, conversationId: String): Flow<List<ChatMessage>> = flow {
        require(userId.isNotBlank() && conversationId.isNotBlank()) {
            "User ID and Conversation ID must not be blank"
        }
        val path = "users/$userId/conversations/$conversationId/messages"
        emitAll(
            db.collection("users").document(userId)
                .collection("conversations").document(conversationId)
                .collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createConversationWithInitialMessage(
        userId: String,
        title: String,
        mode: AssistantMode,
        initialRole: String,
        initialContent: String,
        hasImage: Boolean = false,
        attachmentLabel: String? = null
    ): Result<String> {
        var path = "users/$userId/conversations"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }

            val cleanTitle = title.trim().ifBlank { "Stellar Chat" }.take(120)
            val cleanContent = initialContent.trim().take(16000)
            require(cleanContent.isNotEmpty()) { "Message content must not be empty" }

            val convRef = db.collection("users").document(uid)
                .collection("conversations").document()
            val msgRef = convRef.collection("messages").document()
            path = convRef.path

            val convPayload = mapOf(
                "userId" to uid,
                "title" to cleanTitle,
                "lastMessagePreview" to cleanContent.take(300),
                "mode" to mode.wireValue,
                "messageCount" to 1L,
                "pinned" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val msgPayload = buildMap<String, Any> {
                put("userId", uid)
                put("conversationId", convRef.id)
                put("role", initialRole)
                put("content", cleanContent)
                if (!attachmentLabel.isNullOrBlank()) {
                    put("attachmentLabel", attachmentLabel.take(200))
                }
                put("hasImage", hasImage)
                put("createdAt", FieldValue.serverTimestamp())
            }

            val batch = db.batch()
            batch.set(convRef, convPayload)
            batch.set(msgRef, msgPayload)
            batch.commit().await()

            Result.success(convRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun appendMessage(
        userId: String,
        conversationId: String,
        role: String,
        content: String,
        hasImage: Boolean = false,
        attachmentLabel: String? = null
    ): Result<Unit> {
        val path = "users/$userId/conversations/$conversationId/messages"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            require(conversationId.isNotBlank()) { "Conversation ID must not be blank" }

            val cleanContent = content.trim().take(16000)
            require(cleanContent.isNotEmpty()) { "Message content must not be empty" }

            val convRef = db.collection("users").document(uid)
                .collection("conversations").document(conversationId)
            val msgRef = convRef.collection("messages").document()

            val msgPayload = buildMap<String, Any> {
                put("userId", uid)
                put("conversationId", conversationId)
                put("role", role)
                put("content", cleanContent)
                if (!attachmentLabel.isNullOrBlank()) {
                    put("attachmentLabel", attachmentLabel.take(200))
                }
                put("hasImage", hasImage)
                put("createdAt", FieldValue.serverTimestamp())
            }

            val convUpdates = mapOf(
                "lastMessagePreview" to cleanContent.take(300),
                "messageCount" to FieldValue.increment(1L),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(msgRef, msgPayload)
            batch.update(convRef, convUpdates)
            batch.commit().await()

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun togglePinConversation(
        userId: String,
        conversationId: String,
        pinned: Boolean
    ): Result<Unit> {
        val path = "users/$userId/conversations/$conversationId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            db.collection("users").document(uid)
                .collection("conversations").document(conversationId)
                .update(
                    mapOf(
                        "pinned" to pinned,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteConversation(userId: String, conversationId: String): Result<Unit> {
        val path = "users/$userId/conversations/$conversationId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val convRef = db.collection("users").document(uid)
                .collection("conversations").document(conversationId)
            val msgs = convRef.collection("messages").get().await()
            val batch = db.batch()
            msgs.documents.forEach { doc -> batch.delete(doc.reference) }
            batch.delete(convRef)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun submitAccountDeletionRequest(userId: String, reason: String): Result<Unit> {
        val path = "users/$userId/account_requests"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val reqRef = db.collection("users").document(uid)
                .collection("account_requests").document()
            reqRef.set(
                mapOf(
                    "userId" to uid,
                    "reason" to reason.trim().take(300),
                    "status" to "pending",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun seedSampleConversationsIfEmpty(userId: String, language: AppLanguage): Result<Unit> {
        val path = "users/$userId/conversations"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val existing = db.collection("users").document(uid)
                .collection("conversations").limit(1).get().await()
            if (!existing.isEmpty) return Result.success(Unit)

            val samples = if (language == AppLanguage.THAI) {
                listOf(
                    Triple(
                        "วางแผนทริปเชียงใหม่ 3 วัน 2 คืน",
                        "ช่วยวางแผนเที่ยวเชียงใหม่ 3 วัน 2 คืน แบบชิลล์ๆ เน้นคาเฟ่และธรรมชาติ",
                        "ยินดีเลยค่ะ นี่คือแผนเที่ยวเชียงใหม่ 3 วัน 2 คืน ที่สมดุลทั้งคาเฟ่ ธรรมชาติ และอาหารเหนือ:\n\n• วันที่ 1: ย่านนิมมานฯ — กาแฟดริปยามเช้า, หอศิลป์, และชมพระอาทิตย์ตกที่ดอยสุเทพ\n• วันที่ 2: แม่กำปอง — เดินป่าศึกษาธรรมชาติ, จิบชาชมวิวหมู่บ้านกลางหุบเขา\n• วันที่ 3: ถนนคนเดินท่าแพ / ตลาดวโรรส — ซื้อของฝากและชิมข้าวซอยต้นตำรับก่อนเดินทางกลับค่ะ"
                    ),
                    Triple(
                        "สรุปแนวคิด Clean Architecture บน Android",
                        "อธิบาย MVVM + StateFlow บน Jetpack Compose แบบกระชับ",
                        "โครงสร้าง MVVM ที่แข็งแรงบน Jetpack Compose ประกอบด้วย 3 ชั้นหลักค่ะ:\n\n1. UI Layer (Composable): แสดงผลจาก StateFlow ผ่าน collectAsStateWithLifecycle() และส่งอีเวนต์กลับให้ ViewModel\n2. ViewModel Layer: จัดการ UiState (Loading / Success / Error) ด้วย Coroutines โดยไม่เก็บ Reference ของ Context\n3. Repository Layer: แหล่งข้อมูลเดียวที่เชื่อมต่อ Firebase AI Logic และ Cloud Firestore อย่างปลอดภัย"
                    )
                )
            } else {
                listOf(
                    Triple(
                        "Chiang Mai 3-Day Slow Travel Plan",
                        "Plan a relaxing 3-day Chiang Mai itinerary with cafes and mountain views.",
                        "Here is a balanced 3-day Chiang Mai escape:\n\n• Day 1: Nimmanhaemin specialty coffee crawl, contemporary galleries, and sunset overlooking Doi Suthep.\n• Day 2: Mae Kampong highland village, forest trail walk, and afternoon tea on a wooden terrace.\n• Day 3: Old City temples, Warorot Market local delicacies, and classic Khao Soi before departure."
                    ),
                    Triple(
                        "Jetpack Compose MVVM Overview",
                        "Summarize clean MVVM + StateFlow architecture in Android.",
                        "A resilient Compose MVVM stack relies on clear unidirectional data flow:\n\n1. UI Layer: Stateless Composables observing StateFlow via collectAsStateWithLifecycle().\n2. ViewModel Layer: Maps repository Flows into sealed UiState (Loading, Success, Error).\n3. Data Layer: Repositories mediating Cloud Firestore and Firebase AI Logic safely."
                    )
                )
            }

            samples.forEachIndexed { index, (title, userPrompt, aiReply) ->
                val convRef = db.collection("users").document(uid)
                    .collection("conversations").document()
                val msg1 = convRef.collection("messages").document()
                val msg2 = convRef.collection("messages").document()
                val batch = db.batch()
                batch.set(
                    convRef,
                    mapOf(
                        "userId" to uid,
                        "title" to title,
                        "lastMessagePreview" to aiReply.take(300),
                        "mode" to AssistantMode.CHAT.wireValue,
                        "messageCount" to 2L,
                        "pinned" to (index == 0),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.set(
                    msg1,
                    mapOf(
                        "userId" to uid,
                        "conversationId" to convRef.id,
                        "role" to "user",
                        "content" to userPrompt,
                        "hasImage" to false,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.set(
                    msg2,
                    mapOf(
                        "userId" to uid,
                        "conversationId" to convRef.id,
                        "role" to "assistant",
                        "content" to aiReply,
                        "hasImage" to false,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }
}
