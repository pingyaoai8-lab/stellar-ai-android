package com.example.data.repository

import android.graphics.Bitmap
import android.util.Log
import com.example.core.i18n.AppLanguage
import com.example.domain.model.AiSearchResult
import com.example.domain.model.ChatMessage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

interface AiRepository {
    fun streamChatReply(
        history: List<ChatMessage>,
        userPrompt: String,
        language: AppLanguage
    ): Flow<String>

    suspend fun searchStructured(
        query: String,
        language: AppLanguage
    ): Result<AiSearchResult>

    suspend fun analyzeImage(
        bitmap: Bitmap,
        prompt: String,
        language: AppLanguage
    ): Result<String>

    suspend fun voiceReply(
        transcript: String,
        language: AppLanguage
    ): Result<String>
}

class FirebaseAiRepository : AiRepository {

    private val chatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    "You are Stellar, a warm, intelligent, polished female virtual assistant for STELLAR AI. " +
                        "Provide clear, accurate, well-structured answers. Respect the requested language (Thai or English) " +
                        "and maintain a calm, helpful tone."
                )
            }
        )
    }

    private val searchSchema = Schema.obj(
        properties = mapOf(
            "summary" to Schema.string(description = "Concise executive summary answering the query"),
            "keyTakeaways" to Schema.array(
                items = Schema.string(),
                description = "3 to 5 crisp, actionable key takeaways"
            ),
            "followUpQuestions" to Schema.array(
                items = Schema.string(),
                description = "2 to 3 thoughtful follow-up questions"
            )
        )
    )

    private val structuredSearchModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = searchSchema
            }
        )
    }

    override fun streamChatReply(
        history: List<ChatMessage>,
        userPrompt: String,
        language: AppLanguage
    ): Flow<String> = flow {
        val cleanPrompt = userPrompt.trim()
        require(cleanPrompt.isNotEmpty()) { "Prompt must not be blank" }
        require(cleanPrompt.length <= 4000) { "Prompt exceeds 4,000 character limit" }

        val languageInstruction = if (language == AppLanguage.THAI) {
            "ตอบกลับเป็นภาษาไทยที่สุภาพ ชัดเจน และเป็นธรรมชาติ เว้นแต่ผู้ใช้จะระบุภาษาอื่น"
        } else {
            "Respond in clear, natural English unless the user requests another language."
        }

        val chatHistory = history.takeLast(12).map { msg ->
            content(role = if (msg.fromAssistant) "model" else "user") {
                text(msg.content)
            }
        }

        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                val chat = chatModel.startChat(history = chatHistory)
                val promptWithLang = "[$languageInstruction]\n\n$cleanPrompt"
                chat.sendMessageStream(promptWithLang).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("Model returned an empty response.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Chat streaming timed out", e)
            throw IllegalStateException("Request timed out after 60 seconds. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Chat streaming failed", e)
            throw e
        }
    }

    override suspend fun searchStructured(
        query: String,
        language: AppLanguage
    ): Result<AiSearchResult> {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) {
            return Result.failure(IllegalArgumentException("Search query cannot be empty"))
        }
        val langHint = if (language == AppLanguage.THAI) "Thai" else "English"
        return try {
            val response = withTimeout(60_000L) {
                structuredSearchModel.generateContent(
                    "Provide a structured research synthesis in $langHint for the query: $cleanQuery"
                )
            }
            val rawJson = response.text ?: throw IllegalStateException("Empty structured response")
            val json = JSONObject(rawJson)
            val summary = json.getString("summary")
            val takeawaysArr = json.getJSONArray("keyTakeaways")
            val takeaways = (0 until takeawaysArr.length()).map { takeawaysArr.getString(it) }
            val followUpsArr = json.getJSONArray("followUpQuestions")
            val followUps = (0 until followUpsArr.length()).map { followUpsArr.getString(it) }
            Result.success(
                AiSearchResult(
                    query = cleanQuery,
                    summary = summary,
                    keyTakeaways = takeaways,
                    followUpQuestions = followUps
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Structured search timed out", e)
            Result.failure(IllegalStateException("Search timed out after 60 seconds."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Structured search failed", e)
            Result.failure(e)
        }
    }

    override suspend fun analyzeImage(
        bitmap: Bitmap,
        prompt: String,
        language: AppLanguage
    ): Result<String> {
        val cleanPrompt = prompt.trim().ifBlank {
            if (language == AppLanguage.THAI) "ช่วยวิเคราะห์และอธิบายรายละเอียดของภาพนี้"
            else "Analyze and describe this image in detail."
        }
        val scaledBitmap = scaleBitmapSafely(bitmap, maxDimension = 1280)
        val langDirective = if (language == AppLanguage.THAI) "ตอบเป็นภาษาไทย" else "Respond in English"
        return try {
            val response = withTimeout(60_000L) {
                chatModel.generateContent(
                    content {
                        image(scaledBitmap)
                        text("$langDirective: $cleanPrompt")
                    }
                )
            }
            val text = response.text
            if (text.isNullOrBlank()) {
                Result.failure(IllegalStateException("Model returned an empty visual analysis."))
            } else {
                Result.success(text)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Image analysis timed out", e)
            Result.failure(IllegalStateException("Image analysis timed out after 60 seconds."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Image analysis failed", e)
            Result.failure(e)
        }
    }

    override suspend fun voiceReply(transcript: String, language: AppLanguage): Result<String> {
        val clean = transcript.trim()
        if (clean.isEmpty()) {
            return Result.failure(IllegalArgumentException("Transcript cannot be empty"))
        }
        val langHint = if (language == AppLanguage.THAI) {
            "ตอบกลับเป็นภาษาไทยแบบสั้น กระชับ เป็นธรรมชาติ เหมาะสำหรับอ่านออกเสียง (ไม่เกิน 3-4 ประโยค)"
        } else {
            "Respond in concise, conversational English suitable for spoken audio (3-4 sentences max)."
        }
        return try {
            val response = withTimeout(45_000L) {
                chatModel.generateContent("$langHint\n\nUser said: $clean")
            }
            val text = response.text
            if (text.isNullOrBlank()) {
                Result.failure(IllegalStateException("Empty voice response"))
            } else {
                Result.success(text)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Voice reply timed out", e)
            Result.failure(IllegalStateException("Voice request timed out."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Voice reply failed", e)
            Result.failure(e)
        }
    }

    private fun scaleBitmapSafely(source: Bitmap, maxDimension: Int): Bitmap {
        val width = source.width
        val height = source.height
        if (width <= maxDimension && height <= maxDimension) return source
        val ratio = minOf(maxDimension.toFloat() / width, maxDimension.toFloat() / height)
        val newW = (width * ratio).toInt().coerceAtLeast(1)
        val newH = (height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, newW, newH, true)
    }

    private companion object {
        const val TAG = "FirebaseAiRepo"
    }
}
