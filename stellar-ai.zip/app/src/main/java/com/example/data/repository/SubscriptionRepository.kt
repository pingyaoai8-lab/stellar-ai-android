package com.example.data.repository

import android.app.Activity
import com.example.core.i18n.AppStrings
import com.example.domain.model.BillingConfigState
import com.example.domain.model.EntitlementState
import com.example.domain.model.PlanBillingCycle
import com.example.domain.model.SubscriptionPlan
import com.example.domain.model.SubscriptionTier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface SubscriptionRepository {
    val billingConfigState: StateFlow<BillingConfigState>
    val entitlementState: StateFlow<EntitlementState>

    fun getAvailablePlans(strings: AppStrings): List<SubscriptionPlan>
    suspend fun initiatePurchase(activity: Activity?, plan: SubscriptionPlan): Result<String>
    suspend fun restorePurchases(): Result<EntitlementState>
}

/**
 * Production-structured SubscriptionRepository prepared for Google Play Billing Library
 * and server-side purchase token verification via StellarBackendApi.
 *
 * Intentionally does NOT fake active purchases or grant Pro entitlements without
 * Play Console product IDs and backend verification configured.
 */
class PlayBillingSubscriptionRepository : SubscriptionRepository {

    companion object {
        const val PRODUCT_ID_MONTHLY = "stellar_pro_monthly"
        const val PRODUCT_ID_YEARLY = "stellar_pro_yearly"
    }

    private val _billingConfigState = MutableStateFlow<BillingConfigState>(
        BillingConfigState.NotConfigured(
            reason = "Google Play Billing product IDs and backend entitlement verifier are not yet configured.",
            missingProductIds = listOf(PRODUCT_ID_MONTHLY, PRODUCT_ID_YEARLY)
        )
    )
    override val billingConfigState: StateFlow<BillingConfigState> = _billingConfigState.asStateFlow()

    private val _entitlementState = MutableStateFlow(
        EntitlementState(
            tier = SubscriptionTier.FREE,
            verifiedByBackend = false,
            statusMessage = null
        )
    )
    override val entitlementState: StateFlow<EntitlementState> = _entitlementState.asStateFlow()

    override fun getAvailablePlans(strings: AppStrings): List<SubscriptionPlan> = listOf(
        SubscriptionPlan(
            productId = PRODUCT_ID_MONTHLY,
            cycle = PlanBillingCycle.MONTHLY,
            title = strings.subsMonthlyTitle,
            priceDisplay = strings.subsMonthlyPrice,
            periodDisplay = strings.subsMonthlyPeriod,
            badge = null
        ),
        SubscriptionPlan(
            productId = PRODUCT_ID_YEARLY,
            cycle = PlanBillingCycle.YEARLY,
            title = strings.subsYearlyTitle,
            priceDisplay = strings.subsYearlyPrice,
            periodDisplay = strings.subsYearlyPeriod,
            badge = strings.subsYearlyBadge
        )
    )

    override suspend fun initiatePurchase(
        activity: Activity?,
        plan: SubscriptionPlan
    ): Result<String> {
        return Result.failure(
            IllegalStateException(
                "Play Billing not configured for ${plan.productId}. Configure Play Console & backend verification first."
            )
        )
    }

    override suspend fun restorePurchases(): Result<EntitlementState> {
        return Result.failure(
            IllegalStateException(
                "Play Billing not configured. Cannot query Play Store purchases yet."
            )
        )
    }
}
