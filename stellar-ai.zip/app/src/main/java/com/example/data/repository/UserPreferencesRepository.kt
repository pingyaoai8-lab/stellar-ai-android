package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.i18n.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.stellarDataStore: DataStore<Preferences> by preferencesDataStore(name = "stellar_prefs")

data class LocalAppPreferences(
    val language: AppLanguage = AppLanguage.THAI,
    val onboardingCompleted: Boolean = false,
    val analyticsConsent: Boolean = false,
    val memoryConsent: Boolean = true,
    val voiceAutoSpeak: Boolean = true,
    val customAvatarUri: String? = null
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("preferred_language")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_completed")
        val ANALYTICS_CONSENT = booleanPreferencesKey("analytics_consent")
        val MEMORY_CONSENT = booleanPreferencesKey("memory_consent")
        val VOICE_AUTO_SPEAK = booleanPreferencesKey("voice_auto_speak")
        val CUSTOM_AVATAR_URI = stringPreferencesKey("custom_avatar_uri")
    }

    val preferences: Flow<LocalAppPreferences> = context.stellarDataStore.data.map { prefs ->
        LocalAppPreferences(
            language = AppLanguage.fromCode(prefs[Keys.LANGUAGE]),
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            analyticsConsent = prefs[Keys.ANALYTICS_CONSENT] ?: false,
            memoryConsent = prefs[Keys.MEMORY_CONSENT] ?: true,
            voiceAutoSpeak = prefs[Keys.VOICE_AUTO_SPEAK] ?: true,
            customAvatarUri = prefs[Keys.CUSTOM_AVATAR_URI]?.takeIf { it.isNotBlank() }
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.stellarDataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.stellarDataStore.edit { it[Keys.ONBOARDING_DONE] = completed }
    }

    suspend fun setAnalyticsConsent(enabled: Boolean) {
        context.stellarDataStore.edit { it[Keys.ANALYTICS_CONSENT] = enabled }
    }

    suspend fun setMemoryConsent(enabled: Boolean) {
        context.stellarDataStore.edit { it[Keys.MEMORY_CONSENT] = enabled }
    }

    suspend fun setVoiceAutoSpeak(enabled: Boolean) {
        context.stellarDataStore.edit { it[Keys.VOICE_AUTO_SPEAK] = enabled }
    }

    suspend fun setCustomAvatarUri(uri: String?) {
        context.stellarDataStore.edit {
            if (uri.isNullOrBlank()) {
                it.remove(Keys.CUSTOM_AVATAR_URI)
            } else {
                it[Keys.CUSTOM_AVATAR_URI] = uri
            }
        }
    }
}
