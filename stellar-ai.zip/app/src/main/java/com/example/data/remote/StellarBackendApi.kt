package com.example.data.remote

import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.firebase.Firebase
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.auth.auth
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class BackendChatMessageDto(
    val role: String,
    val content: String
)

@JsonClass(generateAdapter = true)
data class BackendChatRequest(
    val conversationId: String?,
    val messages: List<BackendChatMessageDto>,
    val language: String,
    val mode: String
)

@JsonClass(generateAdapter = true)
data class BackendChatResponse(
    val reply: String,
    val modelUsed: String,
    val rateLimitRemaining: Int? = null
)

@JsonClass(generateAdapter = true)
data class BackendSearchRequest(
    val query: String,
    val language: String
)

@JsonClass(generateAdapter = true)
data class BackendSearchResponse(
    val summary: String,
    val keyTakeaways: List<String>,
    val followUpQuestions: List<String>
)

@JsonClass(generateAdapter = true)
data class BackendVerifyPurchaseRequest(
    val productId: String,
    val purchaseToken: String,
    val packageName: String
)

@JsonClass(generateAdapter = true)
data class BackendVerifyPurchaseResponse(
    val active: Boolean,
    val tier: String,
    val expiresAtEpochMillis: Long? = null
)

@JsonClass(generateAdapter = true)
data class BackendDeleteAccountResponse(
    val status: String,
    val message: String
)

/**
 * Retrofit interface representing Stellar AI's server-side Cloud Functions / Cloud Run gateway.
 * Gemini API keys, service account credentials, and Play Developer API verification secrets
 * must live exclusively behind these server endpoints — never inside the Android APK.
 */
interface StellarBackendApi {

    @POST("v1/chat/completions")
    suspend fun generateChatCompletion(@Body request: BackendChatRequest): BackendChatResponse

    @POST("v1/search/grounded")
    suspend fun searchGrounded(@Body request: BackendSearchRequest): BackendSearchResponse

    @POST("v1/subscriptions/verify")
    suspend fun verifySubscriptionPurchase(
        @Body request: BackendVerifyPurchaseRequest
    ): BackendVerifyPurchaseResponse

    @DELETE("v1/account")
    suspend fun requestAccountDeletion(): BackendDeleteAccountResponse
}

class StellarAuthInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val builder = original.newBuilder()

        try {
            val user = Firebase.auth.currentUser
            if (user != null) {
                val idToken = Tasks.await(user.getIdToken(false), 5, TimeUnit.SECONDS).token
                if (!idToken.isNullOrBlank()) {
                    builder.header("Authorization", "Bearer $idToken")
                }
            }
        } catch (e: Exception) {
            Log.w("StellarBackend", "Could not attach Firebase ID token: ${e.message}")
        }

        try {
            val appCheckToken = Tasks.await(
                FirebaseAppCheck.getInstance().getAppCheckToken(false),
                5,
                TimeUnit.SECONDS
            ).token
            if (appCheckToken.isNotBlank()) {
                builder.header("X-Firebase-AppCheck", appCheckToken)
            }
        } catch (e: Exception) {
            Log.w("StellarBackend", "Could not attach App Check token: ${e.message}")
        }

        return chain.proceed(builder.build())
    }
}

object StellarBackendFactory {
    fun create(baseUrl: String): StellarBackendApi {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(StellarAuthInterceptor())
            .addInterceptor(logging)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        val moshi = Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(StellarBackendApi::class.java)
    }
}
