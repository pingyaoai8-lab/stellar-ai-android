package com.example.core.i18n

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf

@Immutable
data class PromptStarter(
    val title: String,
    val subtitle: String,
    val prompt: String
)

@Immutable
data class FaqEntry(
    val question: String,
    val answer: String
)

@Immutable
data class AppStrings(
    val language: AppLanguage,
    val brandName: String,
    val tagline: String,
    val assistantName: String,

    // Navigation & Common
    val navHome: String,
    val navChat: String,
    val navSearch: String,
    val navVision: String,
    val navHistory: String,
    val navVoice: String,
    val navProfile: String,
    val navSettings: String,
    val navSubscriptions: String,
    val navPrivacy: String,
    val navHelp: String,
    val backLabel: String,
    val skipLabel: String,
    val nextLabel: String,
    val getStartedLabel: String,
    val cancelLabel: String,
    val confirmLabel: String,
    val retryLabel: String,
    val saveLabel: String,
    val closeLabel: String,
    val copiedNotice: String,

    // Onboarding
    val onboardingSlides: List<Pair<String, String>>,

    // Auth
    val authSignInTab: String,
    val authSignUpTab: String,
    val authTitleSignIn: String,
    val authTitleSignUp: String,
    val authSubtitle: String,
    val authGoogleButton: String,
    val authGoogleSignUpButton: String,
    val authProviderNote: String,
    val authConsentPrefix: String,
    val authCancelledError: String,
    val authConfigNote: String,

    // Home Dashboard
    val homeGreetingPrefix: String,
    val homeHeroCardTitle: String,
    val homeHeroCardSubtitle: String,
    val homeStartChatCta: String,
    val homeQuickToolsTitle: String,
    val homeToolChatDesc: String,
    val homeToolSearchDesc: String,
    val homeToolVisionDesc: String,
    val homeToolVoiceDesc: String,
    val homeStartersTitle: String,
    val homePromptStarters: List<PromptStarter>,
    val homeRecentTitle: String,
    val homeViewAllHistory: String,
    val homeNoRecentChats: String,
    val homeBannerProTitle: String,
    val homeBannerProSubtitle: String,

    // Chat
    val chatNewChat: String,
    val chatInputPlaceholder: String,
    val chatSendCd: String,
    val chatStopGeneration: String,
    val chatRegenerate: String,
    val chatCopy: String,
    val chatThinking: String,
    val chatStreamingLabel: String,
    val chatEmptyTitle: String,
    val chatEmptySubtitle: String,
    val chatInputTooLongError: String,
    val chatRateLimitHint: String,
    val chatBackendBadge: String,

    // History
    val historyTitle: String,
    val historySearchPlaceholder: String,
    val historyPinnedSection: String,
    val historyAllSection: String,
    val historyEmptyTitle: String,
    val historyEmptySubtitle: String,
    val historyDeleteTitle: String,
    val historyDeleteBody: String,
    val historyPin: String,
    val historyUnpin: String,
    val historyDelete: String,

    // AI Search
    val searchTitle: String,
    val searchSubtitle: String,
    val searchInputPlaceholder: String,
    val searchButton: String,
    val searchTopics: List<String>,
    val searchSummaryHeader: String,
    val searchTakeawaysHeader: String,
    val searchFollowUpHeader: String,
    val searchAskInChat: String,
    val searchEmptyHint: String,

    // Image Analysis
    val visionTitle: String,
    val visionSubtitle: String,
    val visionPickImage: String,
    val visionChangeImage: String,
    val visionPromptPlaceholder: String,
    val visionAnalyzeButton: String,
    val visionPresets: List<Pair<String, String>>,
    val visionResultTitle: String,
    val visionContinueChat: String,
    val visionEmptyState: String,

    // Voice Assistant
    val voiceTitle: String,
    val voiceSubtitle: String,
    val voiceIdleStatus: String,
    val voiceListeningStatus: String,
    val voiceThinkingStatus: String,
    val voiceSpeakingStatus: String,
    val voiceTapToSpeak: String,
    val voiceTapToStop: String,
    val voiceAutoSpeakLabel: String,
    val voicePermissionRequired: String,
    val voiceFallbackLabel: String,
    val voiceFallbackPlaceholder: String,

    // Profile
    val profileTitle: String,
    val profileDisplayNameLabel: String,
    val profileReplaceAvatar: String,
    val profileResetAvatar: String,
    val profileAvatarHint: String,
    val profileTierLabel: String,
    val profileUpgradeCta: String,
    val profileSavedNotice: String,
    val profileStatsConversations: String,
    val profileDeleteAccountCta: String,

    // Settings
    val settingsTitle: String,
    val settingsLanguageSection: String,
    val settingsLanguageSubtitle: String,
    val settingsPrivacySection: String,
    val settingsAnalyticsLabel: String,
    val settingsAnalyticsDesc: String,
    val settingsMemoryLabel: String,
    val settingsMemoryDesc: String,
    val settingsVoiceSection: String,
    val settingsVoiceAutoSpeak: String,
    val settingsSecuritySection: String,
    val settingsAppCheckStatus: String,
    val settingsBackendGatewayStatus: String,
    val settingsSignOut: String,
    val settingsDeleteAccount: String,
    val settingsDeleteDialogTitle: String,
    val settingsDeleteDialogBody: String,
    val settingsDeleteReasonLabel: String,
    val settingsDeleteSubmitted: String,

    // Subscriptions
    val subsTitle: String,
    val subsSubtitle: String,
    val subsStatusBannerTitle: String,
    val subsStatusBannerBody: String,
    val subsMonthlyTitle: String,
    val subsMonthlyPrice: String,
    val subsMonthlyPeriod: String,
    val subsYearlyTitle: String,
    val subsYearlyPrice: String,
    val subsYearlyPeriod: String,
    val subsYearlyBadge: String,
    val subsFeatures: List<String>,
    val subsSubscribeCta: String,
    val subsRestoreCta: String,
    val subsNotConfiguredMessage: String,

    // Privacy Policy & Help
    val privacyTitle: String,
    val privacyUpdatedLabel: String,
    val privacySections: List<Pair<String, String>>,
    val privacyPlayDisclosureNotice: String,
    val helpTitle: String,
    val helpSubtitle: String,
    val helpFaqs: List<FaqEntry>,
    val helpContactCardTitle: String,
    val helpContactCardBody: String
)

val ThaiStrings = AppStrings(
    language = AppLanguage.THAI,
    brandName = "STELLAR AI",
    tagline = "จักรวาลอัจฉริยะของคุณ",
    assistantName = "สเตลลาร์ (Stellar)",

    navHome = "หน้าหลัก",
    navChat = "แชท AI",
    navSearch = "ค้นหา",
    navVision = "วิเคราะห์ภาพ",
    navHistory = "ประวัติ",
    navVoice = "ผู้ช่วยเสียง",
    navProfile = "โปรไฟล์",
    navSettings = "ตั้งค่า",
    navSubscriptions = "แพ็กเกจ Pro",
    navPrivacy = "ความเป็นส่วนตัว",
    navHelp = "ช่วยเหลือ",
    backLabel = "ย้อนกลับ",
    skipLabel = "ข้าม",
    nextLabel = "ถัดไป",
    getStartedLabel = "เริ่มต้นใช้งาน",
    cancelLabel = "ยกเลิก",
    confirmLabel = "ยืนยัน",
    retryLabel = "ลองใหม่",
    saveLabel = "บันทึก",
    closeLabel = "ปิด",
    copiedNotice = "คัดลอกข้อความแล้ว",

    onboardingSlides = listOf(
        "ผู้ช่วย AI ระดับพรีเมียมคู่ใจ" to "สนทนา วิเคราะห์ภาพ ค้นหาเชิงลึก และสั่งการด้วยเสียงในดีไซน์จักรวาลที่ลื่นไหลเป็นธรรมชาติ",
        "สถาปัตยกรรมความปลอดภัยยุคใหม่" to "ยืนยันตัวตนด้วย Google Sign-In ปกป้องทราฟฟิกด้วย Firebase App Check และซิงก์ข้อมูลส่วนตัวบน Cloud Firestore",
        "พร้อมใช้งานภาษาไทยเป็นค่าเริ่มต้น" to "ออกแบบมาเพื่อความเข้าใจภาษาไทยอย่างแม่นยำ พร้อมรองรับการสลับเป็นภาษาอังกฤษได้ทันทีทุกเมื่อ"
    ),

    authSignInTab = "เข้าสู่ระบบ",
    authSignUpTab = "สร้างบัญชี",
    authTitleSignIn = "ยินดีต้อนรับกลับสู่ Stellar AI",
    authTitleSignUp = "เริ่มต้นจักรวาลอัจฉริยะของคุณ",
    authSubtitle = "เข้าถึงประวัติการสนทนา ข้อมูลวิเคราะห์ และผู้ช่วยส่วนตัวที่ซิงก์อย่างปลอดภัยข้ามอุปกรณ์",
    authGoogleButton = "ดำเนินการต่อด้วย Google",
    authGoogleSignUpButton = "สมัครสมาชิกด้วย Google",
    authProviderNote = "ใช้ Google Sign-In ผ่าน Jetpack Credential Manager เพื่อความปลอดภัยสูงสุดโดยไม่ต้องจำรหัสผ่าน",
    authConsentPrefix = "การดำเนินการต่อถือว่าคุณยอมรับนโยบายความเป็นส่วนตัวของ Stellar AI",
    authCancelledError = "ยกเลิกการเข้าสู่ระบบ กรุณาเลือกบัญชี Google เพื่อดำเนินการต่อ",
    authConfigNote = "เชื่อมต่อ Firebase Authentication + App Check แล้ว",

    homeGreetingPrefix = "สวัสดี",
    homeHeroCardTitle = "พร้อมสำรวจความคิดใหม่ๆ หรือยัง?",
    homeHeroCardSubtitle = "ถามสเตลลาร์ได้ทุกเรื่อง ตั้งแต่สรุปงาน เขียนโค้ด ไปจนถึงวิเคราะห์ภาพถ่าย",
    homeStartChatCta = "เริ่มแชทใหม่",
    homeQuickToolsTitle = "เครื่องมืออัจฉริยะ",
    homeToolChatDesc = "สนทนาแบบสตรีมมิงรวดเร็ว",
    homeToolSearchDesc = "ค้นหาพร้อมสรุปประเด็นสำคัญ",
    homeToolVisionDesc = "วิเคราะห์ภาพด้วย AI มัลติโมดัล",
    homeToolVoiceDesc = "สนทนาด้วยเสียงแบบโต้ตอบ",
    homeStartersTitle = "คำสั่งแนะนำ",
    homePromptStarters = listOf(
        PromptStarter(
            title = "วางแผนทริปสุดสัปดาห์",
            subtitle = "จัดตารางเที่ยวเชียงใหม่ 3 วัน 2 คืน",
            prompt = "ช่วยวางแผนเที่ยวเชียงใหม่ 3 วัน 2 คืน แบบชิลล์ๆ เน้นคาเฟ่ ธรรมชาติ และอาหารท้องถิ่น"
        ),
        PromptStarter(
            title = "สรุปและปรับโทนอีเมลธุรกิจ",
            subtitle = "เขียนอีเมลภาษาไทย/อังกฤษอย่างมืออาชีพ",
            prompt = "ช่วยร่างอีเมลขอเลื่อนนัดประชุมกับลูกค้าอย่างสุภาพและเป็นมืออาชีพ พร้อมสรุปประเด็นเตรียมการ"
        ),
        PromptStarter(
            title = "อธิบายโค้ดและสถาปัตยกรรม",
            subtitle = "วิเคราะห์ Jetpack Compose & Kotlin",
            prompt = "อธิบายแนวทางออกแบบ MVVM + StateFlow บน Jetpack Compose ให้ทำงานลื่นไหลและดูแลรักษาง่าย"
        )
    ),
    homeRecentTitle = "บทสนทนาล่าสุด",
    homeViewAllHistory = "ดูทั้งหมด",
    homeNoRecentChats = "ยังไม่มีประวัติการสนทนา เริ่มต้นแชทแรกของคุณได้เลย",
    homeBannerProTitle = "อัปเกรดเป็น Stellar Pro",
    homeBannerProSubtitle = "ดูรายละเอียดแพ็กเกจรายเดือนและรายปี (รองรับ Play Billing เมื่อพร้อม)",

    chatNewChat = "แชทใหม่",
    chatInputPlaceholder = "พิมพ์คำถามถึง Stellar AI...",
    chatSendCd = "ส่งข้อความ",
    chatStopGeneration = "หยุดสร้างคำตอบ",
    chatRegenerate = "สร้างคำตอบใหม่",
    chatCopy = "คัดลอก",
    chatThinking = "สเตลลาร์กำลังเรียบเรียงคำตอบ...",
    chatStreamingLabel = "กำลังสตรีมคำตอบ",
    chatEmptyTitle = "สวัสดีค่ะ ฉันคือสเตลลาร์",
    chatEmptySubtitle = "พิมพ์คำถาม เลือกคำสั่งแนะนำ หรือแนบภาพจากเมนูวิเคราะห์ภาพเพื่อเริ่มต้นได้เลยค่ะ",
    chatInputTooLongError = "ข้อความยาวเกิน 4,000 ตัวอักษร กรุณาย่อข้อความก่อนส่ง",
    chatRateLimitHint = "กรุณารอสักครู่ระหว่างการส่งคำขอหรือใช้ปุ่มหยุดสร้างคำตอบ",
    chatBackendBadge = "Firebase AI Logic • App Check",

    historyTitle = "ประวัติการสนทนา",
    historySearchPlaceholder = "ค้นหาบทสนทนา...",
    historyPinnedSection = "ปักหมุดไว้",
    historyAllSection = "ทั้งหมด",
    historyEmptyTitle = "ยังไม่มีประวัติที่ตรงกัน",
    historyEmptySubtitle = "บทสนทนาที่คุณสร้างจะถูกบันทึกอย่างปลอดภัยใน Cloud Firestore",
    historyDeleteTitle = "ลบบทสนทนานี้?",
    historyDeleteBody = "ข้อความทั้งหมดในบทสนทนานี้จะถูกลบออกจากบัญชีของคุณอย่างถาวร",
    historyPin = "ปักหมุด",
    historyUnpin = "เลิกปักหมุด",
    historyDelete = "ลบ",

    searchTitle = "AI Search เชิงลึก",
    searchSubtitle = "คำตอบแบบมีโครงสร้าง พร้อมประเด็นหลักและคำถามต่อยอด",
    searchInputPlaceholder = "ค้นหาหัวข้อที่ต้องการเจาะลึก...",
    searchButton = "ค้นหาด้วย AI",
    searchTopics = listOf("ปัญญาประดิษฐ์ 2026", "การลงทุนเบื้องต้น", "Kotlin Multiplatform", "สุขภาพและการนอน"),
    searchSummaryHeader = "สรุปภาพรวม",
    searchTakeawaysHeader = "ประเด็นสำคัญ",
    searchFollowUpHeader = "คำถามต่อยอด",
    searchAskInChat = "ถามต่อในแชท",
    searchEmptyHint = "พิมพ์หัวข้อหรือเลือกหัวข้อยอดนิยมด้านบนเพื่อรับสรุปแบบมีโครงสร้าง",

    visionTitle = "วิเคราะห์ภาพอัจฉริยะ",
    visionSubtitle = "เลือกภาพผ่าน Android Photo Picker ที่ปลอดภัยโดยไม่ขอสิทธิ์เข้าถึงไฟล์ทั้งหมด",
    visionPickImage = "เลือกรูปภาพ",
    visionChangeImage = "เปลี่ยนรูปภาพ",
    visionPromptPlaceholder = "ถามเกี่ยวกับภาพนี้ เช่น แปลข้อความ หรือวิเคราะห์องค์ประกอบ...",
    visionAnalyzeButton = "วิเคราะห์ภาพ",
    visionPresets = listOf(
        "อธิบายภาพนี้" to "ช่วยอธิบายรายละเอียดสำคัญ บรรยากาศ และวัตถุที่เห็นในภาพนี้อย่างชัดเจนเป็นภาษาไทย",
        "ถอดข้อความ (OCR)" to "ช่วยถอดข้อความทั้งหมดที่ปรากฏในภาพนี้ พร้อมจัดระเบียบให้อ่านง่าย",
        "สรุปเอกสาร/สไลด์" to "ช่วยสรุปใจความสำคัญจากภาพเอกสารหรือสไลด์นี้เป็นข้อๆ",
        "คิดแคปชันสร้างสรรค์" to "ช่วยคิดแคปชันภาษาไทยที่ดูดีและทันสมัยสำหรับภาพนี้ 3 แบบ"
    ),
    visionResultTitle = "ผลการวิเคราะห์จาก Stellar AI",
    visionContinueChat = "บันทึกและคุยต่อในแชท",
    visionEmptyState = "แตะ \"เลือกรูปภาพ\" เพื่อวิเคราะห์ภาพถ่าย เอกสาร หรือภาพหน้าจอ",

    voiceTitle = "ผู้ช่วยเสียง Stellar",
    voiceSubtitle = "โต้ตอบด้วยเสียงอย่างเป็นธรรมชาติ พร้อมโหมดพิมพ์สำรอง",
    voiceIdleStatus = "แตะไมโครโฟนเพื่อเริ่มพูดกับสเตลลาร์",
    voiceListeningStatus = "กำลังฟังเสียงของคุณ...",
    voiceThinkingStatus = "กำลังประมวลผลคำตอบ...",
    voiceSpeakingStatus = "สเตลลาร์กำลังตอบกลับ...",
    voiceTapToSpeak = "เริ่มพูด",
    voiceTapToStop = "หยุดฟัง",
    voiceAutoSpeakLabel = "อ่านออกเสียงคำตอบอัตโนมัติ",
    voicePermissionRequired = "ต้องอนุญาตสิทธิ์ไมโครโฟนเพื่อใช้การรับเสียง หรือพิมพ์คำถามด้านล่างได้ทันที",
    voiceFallbackLabel = "พิมพ์คำถามแทนการพูด",
    voiceFallbackPlaceholder = "พิมพ์ข้อความสำหรับผู้ช่วยเสียง...",

    profileTitle = "โปรไฟล์และอวตาร",
    profileDisplayNameLabel = "ชื่อที่แสดง",
    profileReplaceAvatar = "เปลี่ยนภาพอวตารผู้ช่วย",
    profileResetAvatar = "ใช้ภาพต้นฉบับ",
    profileAvatarHint = "สามารถเปลี่ยนภาพประจำตัวผู้ช่วย Stellar ได้ด้วยรูปที่คุณเลือก (ใช้ Photo Picker แบบปลอดภัย)",
    profileTierLabel = "สถานะสมาชิก",
    profileUpgradeCta = "ดูแพ็กเกจ Stellar Pro",
    profileSavedNotice = "บันทึกข้อมูลโปรไฟล์แล้ว",
    profileStatsConversations = "บทสนทนาทั้งหมด",
    profileDeleteAccountCta = "ขอลบบัญชีและข้อมูลทั้งหมด",

    settingsTitle = "การตั้งค่า",
    settingsLanguageSection = "ภาษา (Language)",
    settingsLanguageSubtitle = "ภาษาไทยเป็นค่าเริ่มต้นของแอป สามารถสลับเป็นภาษาอังกฤษได้ทันที",
    settingsPrivacySection = "ความเป็นส่วนตัวและความยินยอม",
    settingsAnalyticsLabel = "แบ่งปันข้อมูลวินิจฉัยแบบไม่ระบุตัวตน",
    settingsAnalyticsDesc = "ช่วยปรับปรุงเสถียรภาพแอป (ไม่มีการส่งเนื้อหาแชท)",
    settingsMemoryLabel = "จดจำบริบทการสนทนา",
    settingsMemoryDesc = "ช่วยให้ Stellar AI ตอบได้ต่อเนื่องสอดคล้องกับสไตล์ของคุณ",
    settingsVoiceSection = "เสียงและการโต้ตอบ",
    settingsVoiceAutoSpeak = "เปิดอ่านออกเสียงคำตอบในโหมดผู้ช่วยเสียง",
    settingsSecuritySection = "ความปลอดภัยและระบบหลังบ้าน",
    settingsAppCheckStatus = "Firebase App Check: เปิดใช้งานการยืนยันตัวตนแอปแล้ว",
    settingsBackendGatewayStatus = "Gateway: Firebase AI Logic + Backend Proxy Interface พร้อมกำหนดค่า",
    settingsSignOut = "ออกจากระบบ",
    settingsDeleteAccount = "ลบบัญชีผู้ใช้",
    settingsDeleteDialogTitle = "ยืนยันคำขอลบบัญชี",
    settingsDeleteDialogBody = "ระบบจะบันทึกคำขอลบบัญชีและข้อมูลของคุณไว้ในสถานะรอดำเนินการ และออกจากระบบทันที สำหรับการใช้งานจริงบน Play Store ต้องเชื่อมต่อ Cloud Function ลบข้อมูลฝั่งเซิร์ฟเวอร์ให้สมบูรณ์",
    settingsDeleteReasonLabel = "เหตุผล (ไม่บังคับ)",
    settingsDeleteSubmitted = "ส่งคำขอลบบัญชีแล้ว",

    subsTitle = "แพ็กเกจ Stellar Pro",
    subsSubtitle = "ยกระดับการประมวลผลอัจฉริยะและโควตารายวัน",
    subsStatusBannerTitle = "การตั้งค่า Google Play Billing (ยังไม่เปิดรับชำระเงินจริง)",
    subsStatusBannerBody = "หน้าจอนี้ออกแบบตามโครงสร้าง Play Billing + การตรวจสิทธิ์ฝั่งเซิร์ฟเวอร์ (Backend Entitlement Verification) โดยไม่มีการจำลองการซื้อปลอม กรุณาตั้งค่า Product IDs ใน Play Console และ Backend ก่อนเผยแพร่",
    subsMonthlyTitle = "Stellar Pro รายเดือน",
    subsMonthlyPrice = "฿299",
    subsMonthlyPeriod = "/ เดือน",
    subsYearlyTitle = "Stellar Pro รายปี",
    subsYearlyPrice = "฿2,490",
    subsYearlyPeriod = "/ ปี",
    subsYearlyBadge = "ประหยัด 30%",
    subsFeatures = listOf(
        "สิทธิ์เข้าถึงโมเดลความสามารถสูงและบริบทที่ยาวขึ้น",
        "วิเคราะห์ภาพและเอกสารความละเอียดสูงได้ไม่สะดุด",
        "ซิงก์ประวัติการสนทนาและการค้นหาข้ามอุปกรณ์ผ่าน Cloud Firestore",
        "รองรับการตรวจสอบสิทธิ์การสมัครสมาชิกผ่าน Backend Server"
    ),
    subsSubscribeCta = "สมัครสมาชิกผ่าน Play Billing",
    subsRestoreCta = "กู้คืนการสั่งซื้อ",
    subsNotConfiguredMessage = "Google Play Billing ยังไม่ถูกเปิดใช้งาน: ต้องกำหนด Product IDs บน Google Play Console และ Backend Verification Endpoint ก่อนจึงจะสั่งซื้อได้",

    privacyTitle = "นโยบายความเป็นส่วนตัว & Data Safety",
    privacyUpdatedLabel = "เทมเพลตเตรียมความพร้อมสำหรับ Google Play • ต้องตรวจสอบและระบุข้อมูลองค์กรก่อนเผยแพร่",
    privacySections = listOf(
        "1. ข้อมูลที่เราจัดเก็บ [TO BE COMPLETED BEFORE PLAY RELEASE]" to "บัญชี Google (ชื่อ อีเมล รหัสผู้ใช้ Firebase UID), ประวัติการสนทนาใน Cloud Firestore และรูปภาพที่ผู้ใช้เลือกส่งวิเคราะห์ (ไม่เก็บสิทธิ์เข้าถึงคลังภาพทั้งหมด)",
        "2. การประมวลผลด้วย AI และความปลอดภัย" to "คำขอ AI ใช้การยืนยันความถูกต้องของแอปผ่าน Firebase App Check และออกแบบให้เชื่อมต่อกับเซิร์ฟเวอร์ Backend (Cloud Functions / Cloud Run) โดยไม่ฝัง API Key ไว้ในตัวแอป",
        "3. สิทธิ์ของผู้ใช้และการลบข้อมูล" to "ผู้ใช้สามารถปรับการยินยอมด้านข้อมูลและการลบบัญชีได้ตลอดเวลาผ่านหน้าตั้งค่าและโปรไฟล์ ตามข้อกำหนด Account Deletion ของ Google Play"
    ),
    privacyPlayDisclosureNotice = "คำเตือนก่อนเปิดตัว: กรุณากรอกชื่อผู้พัฒนา ที่อยู่อีเมลติดต่อ DPO และแบบฟอร์ม Data Safety ใน Google Play Console ให้ครบถ้วนก่อนนำส่งแอป",

    helpTitle = "ศูนย์ช่วยเหลือ",
    helpSubtitle = "คำถามที่พบบ่อย คู่มือสถาปัตยกรรม และสถานะระบบ",
    helpFaqs = listOf(
        FaqEntry(
            "Stellar AI ใช้โมเดลและสถาปัตยกรรมแบบใด?",
            "ตัวแอปทำงานบน Kotlin + Jetpack Compose เชื่อมต่อ Firebase Authentication, Cloud Firestore, Firebase App Check และ Firebase AI Logic พร้อมอินเทอร์เฟซ Retrofit สำหรับ Proxy Backend ของคุณ"
        ),
        FaqEntry(
            "เหตุใดระบบการชำระเงินจึงยังไม่หักเงินจริง?",
            "เพื่อความปลอดภัยและความโปร่งใส แอปไม่ได้จำลองการสั่งซื้อปลอม ระบบจะทำงานผ่าน Google Play Billing Library และตรวจสอบ Token ฝั่ง Backend เมื่อคุณตั้งค่า Play Console Product IDs เรียบร้อยแล้ว"
        ),
        FaqEntry(
            "จะเปลี่ยนภาพผู้ช่วยหรือสลับภาษาได้อย่างไร?",
            "เปลี่ยนภาพผู้ช่วยได้ที่หน้าโปรไฟล์โดยใช้ Photo Picker แบบไม่ต้องขอสิทธิ์ Storage และสลับภาษาไทย/อังกฤษได้ที่หน้าตั้งค่าหรือหน้าต้อนรับ"
        )
    ),
    helpContactCardTitle = "ข้อมูลสำหรับทีมพัฒนา & การตรวจสอบ",
    helpContactCardBody = "ดูไฟล์ README.md ในโปรเจกต์สำหรับขั้นตอนการตั้งค่า Firebase, App Check, Cloud Functions / Cloud Run และ Google Play Billing"
)

val EnglishStrings = AppStrings(
    language = AppLanguage.ENGLISH,
    brandName = "STELLAR AI",
    tagline = "Your Intelligent Universe",
    assistantName = "Stellar",

    navHome = "Home",
    navChat = "AI Chat",
    navSearch = "Search",
    navVision = "Vision",
    navHistory = "History",
    navVoice = "Voice",
    navProfile = "Profile",
    navSettings = "Settings",
    navSubscriptions = "Stellar Pro",
    navPrivacy = "Privacy",
    navHelp = "Help",
    backLabel = "Back",
    skipLabel = "Skip",
    nextLabel = "Next",
    getStartedLabel = "Get Started",
    cancelLabel = "Cancel",
    confirmLabel = "Confirm",
    retryLabel = "Retry",
    saveLabel = "Save",
    closeLabel = "Close",
    copiedNotice = "Copied to clipboard",

    onboardingSlides = listOf(
        "Your Elevated Cosmic AI Companion" to "Converse, analyze images, run structured deep searches, and interact by voice inside a refined dark-navy interface.",
        "Security-First Architecture" to "Powered by Google Sign-In, Firebase App Check attestation, scoped Cloud Firestore rules, and a backend-ready API gateway.",
        "Bilingual Thai & English Foundation" to "Thai is configured as the default experience with instant in-app switching to English at any time."
    ),

    authSignInTab = "Sign In",
    authSignUpTab = "Sign Up",
    authTitleSignIn = "Welcome back to Stellar AI",
    authTitleSignUp = "Launch Your Intelligent Universe",
    authSubtitle = "Sync your conversations, preferences, and AI workspace securely across devices.",
    authGoogleButton = "Continue with Google",
    authGoogleSignUpButton = "Create Account with Google",
    authProviderNote = "Uses Google Sign-In via Jetpack Credential Manager for passwordless, hardware-backed security.",
    authConsentPrefix = "By continuing, you acknowledge the Stellar AI Privacy Policy.",
    authCancelledError = "Sign-in was cancelled. Select a Google account to continue.",
    authConfigNote = "Protected by Firebase Authentication & App Check",

    homeGreetingPrefix = "Hello",
    homeHeroCardTitle = "Ready to explore something brilliant?",
    homeHeroCardSubtitle = "Ask Stellar anything — from strategic planning and coding to multimodal visual analysis.",
    homeStartChatCta = "Start New Chat",
    homeQuickToolsTitle = "Cosmic Suite",
    homeToolChatDesc = "Streaming multi-turn AI chat",
    homeToolSearchDesc = "Structured AI takeaways",
    homeToolVisionDesc = "Zero-permission photo analysis",
    homeToolVoiceDesc = "Hands-free voice assistant",
    homeStartersTitle = "Prompt Starters",
    homePromptStarters = listOf(
        PromptStarter(
            title = "Weekend Escape Planner",
            subtitle = "3-day Chiang Mai slow-travel itinerary",
            prompt = "Plan a relaxing 3-day 2-night Chiang Mai itinerary with specialty coffee, nature spots, and local cuisine."
        ),
        PromptStarter(
            title = "Executive Email Polish",
            subtitle = "Crisp, diplomatic client follow-up",
            prompt = "Draft a polite, professional email rescheduling a client roadmap review with clear action items."
        ),
        PromptStarter(
            title = "Kotlin Architecture Review",
            subtitle = "Jetpack Compose + StateFlow patterns",
            prompt = "Explain clean MVVM + StateFlow architecture best practices in Jetpack Compose for scalable Android apps."
        )
    ),
    homeRecentTitle = "Recent Conversations",
    homeViewAllHistory = "View All",
    homeNoRecentChats = "No conversations yet. Start your first cosmic thread.",
    homeBannerProTitle = "Explore Stellar Pro",
    homeBannerProSubtitle = "View monthly & yearly plans (Google Play Billing integration-ready)",

    chatNewChat = "New Chat",
    chatInputPlaceholder = "Ask Stellar AI anything...",
    chatSendCd = "Send message",
    chatStopGeneration = "Stop generating",
    chatRegenerate = "Regenerate",
    chatCopy = "Copy",
    chatThinking = "Stellar is composing a response...",
    chatStreamingLabel = "Streaming live",
    chatEmptyTitle = "Hello, I'm Stellar",
    chatEmptySubtitle = "Type a prompt, pick a starter, or analyze an image to begin your session.",
    chatInputTooLongError = "Prompt exceeds 4,000 characters. Please shorten your message.",
    chatRateLimitHint = "Please wait briefly between requests or tap Stop to interrupt.",
    chatBackendBadge = "Firebase AI Logic • App Check",

    historyTitle = "Conversation History",
    historySearchPlaceholder = "Search conversations...",
    historyPinnedSection = "Pinned",
    historyAllSection = "All Conversations",
    historyEmptyTitle = "No matching conversations",
    historyEmptySubtitle = "Your threads are securely stored per-user in Cloud Firestore.",
    historyDeleteTitle = "Delete this conversation?",
    historyDeleteBody = "All messages inside this conversation will be permanently removed from your account.",
    historyPin = "Pin",
    historyUnpin = "Unpin",
    historyDelete = "Delete",

    searchTitle = "AI Deep Search",
    searchSubtitle = "Structured synthesis with key takeaways and follow-up paths",
    searchInputPlaceholder = "Search any topic in depth...",
    searchButton = "Search with AI",
    searchTopics = listOf("AI Trends 2026", "Clean Architecture", "Quantum Computing", "Sleep Science"),
    searchSummaryHeader = "Executive Summary",
    searchTakeawaysHeader = "Key Takeaways",
    searchFollowUpHeader = "Follow-Up Questions",
    searchAskInChat = "Continue in Chat",
    searchEmptyHint = "Enter a topic or tap a suggestion above for a structured AI synthesis.",

    visionTitle = "Image Analysis",
    visionSubtitle = "Uses zero-permission Android Photo Picker with multimodal Gemini vision",
    visionPickImage = "Choose Photo",
    visionChangeImage = "Change Photo",
    visionPromptPlaceholder = "Ask about this photo (extract text, explain diagram, caption)...",
    visionAnalyzeButton = "Analyze Image",
    visionPresets = listOf(
        "Describe Image" to "Describe the key subjects, composition, and visual details of this image clearly.",
        "Extract Text (OCR)" to "Extract and cleanly format all visible text from this image.",
        "Summarize Document" to "Summarize the main points and action items shown in this document or slide.",
        "Creative Captions" to "Write 3 refined, modern captions suited for this image."
    ),
    visionResultTitle = "Stellar Visual Insights",
    visionContinueChat = "Save & Continue in Chat",
    visionEmptyState = "Tap \"Choose Photo\" to analyze photos, documents, or screenshots.",

    voiceTitle = "Voice Assistant",
    voiceSubtitle = "Natural spoken interaction with instant text fallback",
    voiceIdleStatus = "Tap the orb to speak with Stellar",
    voiceListeningStatus = "Listening...",
    voiceThinkingStatus = "Thinking...",
    voiceSpeakingStatus = "Stellar is speaking...",
    voiceTapToSpeak = "Speak",
    voiceTapToStop = "Stop",
    voiceAutoSpeakLabel = "Auto-speak responses (TTS)",
    voicePermissionRequired = "Microphone permission is needed for voice capture, or type below anytime.",
    voiceFallbackLabel = "Type instead of speaking",
    voiceFallbackPlaceholder = "Enter a voice prompt...",

    profileTitle = "Profile & Avatar",
    profileDisplayNameLabel = "Display Name",
    profileReplaceAvatar = "Replace Assistant Avatar",
    profileResetAvatar = "Reset to Default",
    profileAvatarHint = "Customize Stellar's avatar using the zero-permission Android Photo Picker.",
    profileTierLabel = "Membership Tier",
    profileUpgradeCta = "View Stellar Pro Plans",
    profileSavedNotice = "Profile updated",
    profileStatsConversations = "Saved Conversations",
    profileDeleteAccountCta = "Request Account & Data Deletion",

    settingsTitle = "Settings",
    settingsLanguageSection = "Language",
    settingsLanguageSubtitle = "Thai is the default language; switch between Thai and English anytime.",
    settingsPrivacySection = "Privacy & Consent",
    settingsAnalyticsLabel = "Anonymized Diagnostics",
    settingsAnalyticsDesc = "Helps improve app reliability without collecting chat content",
    settingsMemoryLabel = "Conversation Context Memory",
    settingsMemoryDesc = "Allows Stellar AI to tailor responses across turns",
    settingsVoiceSection = "Voice & Audio",
    settingsVoiceAutoSpeak = "Read voice assistant responses aloud",
    settingsSecuritySection = "Security & Backend Readiness",
    settingsAppCheckStatus = "Firebase App Check: Active for debug & release attestation",
    settingsBackendGatewayStatus = "Gateway: Firebase AI Logic + Backend Proxy Interface ready",
    settingsSignOut = "Sign Out",
    settingsDeleteAccount = "Delete Account",
    settingsDeleteDialogTitle = "Submit Account Deletion Request",
    settingsDeleteDialogBody = "This records a pending deletion request for your account and signs you out. Complete server-side deletion via Cloud Functions before Play Store launch.",
    settingsDeleteReasonLabel = "Reason (optional)",
    settingsDeleteSubmitted = "Account deletion request recorded",

    subsTitle = "Stellar Pro Plans",
    subsSubtitle = "Designed for high-throughput reasoning and priority features",
    subsStatusBannerTitle = "Google Play Billing Configuration Required",
    subsStatusBannerBody = "Purchases are intentionally NOT faked. Real transactions require Play Console product IDs (stellar_pro_monthly, stellar_pro_yearly) and backend entitlement verification.",
    subsMonthlyTitle = "Stellar Pro Monthly",
    subsMonthlyPrice = "$8.99",
    subsMonthlyPeriod = "/ month",
    subsYearlyTitle = "Stellar Pro Yearly",
    subsYearlyPrice = "$74.99",
    subsYearlyPeriod = "/ year",
    subsYearlyBadge = "Save 30%",
    subsFeatures = listOf(
        "Higher daily limits and extended reasoning context",
        "Priority multimodal image and document analysis",
        "Cross-device conversation sync via Cloud Firestore",
        "Server-verified subscription entitlements via Backend API"
    ),
    subsSubscribeCta = "Subscribe via Play Billing",
    subsRestoreCta = "Restore Purchases",
    subsNotConfiguredMessage = "Google Play Billing is not configured yet. Configure Play Console product IDs and backend verification before enabling live purchases.",

    privacyTitle = "Privacy Policy & Data Safety",
    privacyUpdatedLabel = "Pre-release compliance template • Complete legal & Data Safety fields before Play Store submission",
    privacySections = listOf(
        "1. Data Collected [TO BE COMPLETED BEFORE PLAY RELEASE]" to "Google account identifiers (UID, display name, email), per-user conversations in Cloud Firestore, and user-selected photos submitted for analysis via Android Photo Picker.",
        "2. AI Processing & Security" to "AI traffic is attested via Firebase App Check and designed for server-side mediation (Cloud Functions / Cloud Run) with zero client-side API keys or secrets.",
        "3. User Rights & Account Deletion" to "You may update consent toggles or submit an account deletion request anytime in Profile or Settings in accordance with Google Play's Data Deletion policy."
    ),
    privacyPlayDisclosureNotice = "Release checklist: Add your legal entity name, privacy contact email, and complete the Google Play Console Data Safety form prior to publishing.",

    helpTitle = "Help & Architecture Guide",
    helpSubtitle = "FAQs, security posture, and developer setup checklist",
    helpFaqs = listOf(
        FaqEntry(
            "How are AI calls and keys secured?",
            "Stellar AI uses Firebase AI Logic protected by App Check and defines a Retrofit backend proxy interface for Cloud Functions / Cloud Run. No Gemini keys or payment secrets are embedded in the APK."
        ),
        FaqEntry(
            "Why doesn't the Subscribe button complete a purchase?",
            "Per commercial integrity standards, purchases are never faked. Connect your Play Console product IDs and backend entitlement verifier first."
        ),
        FaqEntry(
            "How do I replace the assistant avatar or switch languages?",
            "Open Profile to pick a custom avatar via Android Photo Picker, or open Settings to switch between Thai (default) and English."
        )
    ),
    helpContactCardTitle = "Developer Setup & Launch Readiness",
    helpContactCardBody = "See README.md in the project root for step-by-step Firebase, App Check, Cloud Functions / Cloud Run, and Play Billing instructions."
)

fun stringsFor(language: AppLanguage): AppStrings =
    if (language == AppLanguage.THAI) ThaiStrings else EnglishStrings

val LocalAppStrings = staticCompositionLocalOf { ThaiStrings }
