package com.example.core.i18n

enum class AppLanguage(val code: String, val nativeLabel: String, val englishLabel: String) {
    THAI("th", "ไทย (ค่าเริ่มต้น)", "Thai (Default)"),
    ENGLISH("en", "English", "English");

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: THAI
    }
}
