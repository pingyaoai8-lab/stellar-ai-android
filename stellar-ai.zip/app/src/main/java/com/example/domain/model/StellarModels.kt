package com.example.domain.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties

enum class SubscriptionTier(val wireValue: String) {
    FREE("free"),
    PRO_MONTHLY("pro_monthly"),
    PRO_YEARLY("pro_yearly");

    companion object {
        fun fromWire(value: String?): SubscriptionTier =
            entries.firstOrNull { it.wireValue == value } ?: FREE
    }
}

enum class AssistantMode(val wireValue: String) {
    CHAT("chat"),
    SEARCH("search"),
    VISION("vision"),
    VOICE("voice");

    companion object {
        fun fromWire(value: String?): AssistantMode =
            entries.firstOrNull { it.wireValue == value } ?: CHAT
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String? = null,
    val avatarPreset: String = "stellar_default",
    val customAvatarUri: String? = null,
    val preferredLanguage: String = "th",
    val analyticsConsent: Boolean = false,
    val memoryConsent: Boolean = true,
    val subscriptionTier: String = SubscriptionTier.FREE.wireValue,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    val tierEnum: SubscriptionTier
        get() = SubscriptionTier.fromWire(subscriptionTier)
}

@Keep
@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val lastMessagePreview: String = "",
    val mode: String = AssistantMode.CHAT.wireValue,
    val messageCount: Long = 0L,
    val pinned: Boolean = false,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    val modeEnum: AssistantMode
        get() = AssistantMode.fromWire(mode)
}

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val conversationId: String = "",
    val role: String = "user",
    val content: String = "",
    val attachmentLabel: String? = null,
    val hasImage: Boolean = false,
    val createdAt: Timestamp? = null
) {
    val fromAssistant: Boolean
        get() = role == "assistant"
}

data class AiSearchResult(
    val query: String,
    val summary: String,
    val keyTakeaways: List<String>,
    val followUpQuestions: List<String>
)
