package com.example.domain.model

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class PlanBillingCycle {
    MONTHLY,
    YEARLY
}

data class SubscriptionPlan(
    val productId: String,
    val cycle: PlanBillingCycle,
    val title: String,
    val priceDisplay: String,
    val periodDisplay: String,
    val badge: String? = null
)

sealed interface BillingConfigState {
    data class NotConfigured(
        val reason: String,
        val missingProductIds: List<String>
    ) : BillingConfigState

    data object Ready : BillingConfigState
}

data class EntitlementState(
    val tier: SubscriptionTier = SubscriptionTier.FREE,
    val verifiedByBackend: Boolean = false,
    val statusMessage: String? = null
)
